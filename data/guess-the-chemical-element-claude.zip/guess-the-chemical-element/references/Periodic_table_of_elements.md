# Periodic table of elements – data for the chatbot

This table lists all 118 chemical elements with the data the chatbot "Guess the Chemical Element" uses to build riddles and follow-up facts for students aged 12–15. Take facts about elements from this table; add anything that is not here only from verified general knowledge.

## Legend

- **Z** – atomic number (number of protons in the nucleus).
- **Symbol** – chemical symbol. Never reveal it in a riddle: it would give the name away.
- **Name** – English name as recommended by IUPAC (see spelling variants below).
- **Group** – column 1–18 of the periodic table. Lanthanides and actinides (f-block) have "–": they are shown in separate rows below the main table. Periodic tables differ on whether lanthanum and actinium or lutetium and lawrencium are placed in group 3.
- **Period** – row 1–7 (equal to the number of electron shells).
- **Category** – alkali metal, alkaline earth metal, transition metal, post-transition metal, metalloid, nonmetal, halogen, noble gas, lanthanide, actinide. Hydrogen sits in group 1 but is a nonmetal. Group 12 (zinc, cadmium, mercury) is counted here with the transition metals, as in many school tables; some tables list it separately. Category labels for borderline elements (for example polonium) vary between sources.
- **State (25 °C)** – at 25 °C and normal pressure. "Solid (predicted)" = the element has never been made in a large enough amount to see. "Unknown" = only a few atoms have ever been made.
- **Valence e⁻** – number of valence electrons, given only for main-group elements (groups 1, 2 and 13–18). Transition metals, lanthanides and actinides have "–".
- **Use / fun fact** – a short typical property, use or fun fact.
- For superheavy elements (Z ≥ 104) the category and state are only predicted from their position in the table.

## Table of elements

| Z | Symbol | Name | Group | Period | Category | State (25 °C) | Valence e⁻ | Use / fun fact |
|---|---|---|---|---|---|---|---|---|
| 1 | H | hydrogen | 1 | 1 | nonmetal | gas | 1 | Lightest element and the most abundant in the universe; part of water (H₂O); fuel for hydrogen fuel cells. |
| 2 | He | helium | 18 | 1 | noble gas | gas | 2 | Lighter than air – fills party balloons and airships; liquid helium cools the magnets of MRI scanners. |
| 3 | Li | lithium | 1 | 2 | alkali metal | solid | 1 | Lightest metal; used in lithium-ion batteries in phones and electric cars. |
| 4 | Be | beryllium | 2 | 2 | alkaline earth metal | solid | 2 | Light, stiff metal for aerospace (the mirrors of the James Webb Space Telescope); its compounds are toxic. |
| 5 | B | boron | 13 | 2 | metalloid | solid | 3 | Used in heat-resistant borosilicate glass (lab glassware, ovenware); boric acid. |
| 6 | C | carbon | 14 | 2 | nonmetal | solid | 4 | Basis of all organic compounds and of life; forms both diamond and graphite (the "lead" in pencils). |
| 7 | N | nitrogen | 15 | 2 | nonmetal | gas | 5 | Makes up about 78% of air; used to make fertilizers; liquid nitrogen boils at −196 °C. |
| 8 | O | oxygen | 16 | 2 | nonmetal | gas | 6 | Makes up about 21% of air; needed for breathing and burning; the most abundant element in Earth's crust. |
| 9 | F | fluorine | 17 | 2 | halogen | gas | 7 | Most reactive nonmetal; fluoride in toothpaste protects teeth; part of Teflon (non-stick coatings). |
| 10 | Ne | neon | 18 | 2 | noble gas | gas | 8 | Glows red-orange in neon signs. |
| 11 | Na | sodium | 1 | 3 | alkali metal | solid | 1 | Soft metal that can be cut with a knife and reacts violently with water; part of table salt (NaCl). |
| 12 | Mg | magnesium | 2 | 3 | alkaline earth metal | solid | 2 | Light metal for alloys (bikes, aircraft); burns with a dazzling white flame; found in chlorophyll. |
| 13 | Al | aluminium | 13 | 3 | post-transition metal | solid | 3 | Most abundant metal in Earth's crust; light – kitchen foil, drink cans, aircraft. |
| 14 | Si | silicon | 14 | 3 | metalloid | solid | 4 | Basis of semiconductors, computer chips and solar cells; sand is mostly silicon dioxide (quartz). |
| 15 | P | phosphorus | 15 | 3 | nonmetal | solid | 5 | White phosphorus catches fire in air by itself, red phosphorus is on the striking strip of matchboxes; found in bones and DNA. |
| 16 | S | sulfur | 16 | 3 | nonmetal | solid | 6 | Yellow solid; used to make sulfuric acid and to vulcanize rubber; the rotten-egg smell comes from hydrogen sulfide. |
| 17 | Cl | chlorine | 17 | 3 | halogen | gas | 7 | Yellow-green toxic gas; disinfects water (swimming pools); part of table salt. |
| 18 | Ar | argon | 18 | 3 | noble gas | gas | 8 | Most common noble gas in air (about 0.9%); shielding gas in welding; fills light bulbs. |
| 19 | K | potassium | 1 | 4 | alkali metal | solid | 1 | Soft, very reactive metal; potassium fertilizers; nerves and muscles need it (bananas are rich in it). |
| 20 | Ca | calcium | 2 | 4 | alkaline earth metal | solid | 2 | Builds bones and teeth; limestone, lime and plaster in construction. |
| 21 | Sc | scandium | 3 | 4 | transition metal | solid | – | Light alloys with aluminium (bike frames, sports equipment). |
| 22 | Ti | titanium | 4 | 4 | transition metal | solid | – | Strong, light and corrosion-resistant – implants, aircraft, eyeglass frames; titanium dioxide is a white pigment. |
| 23 | V | vanadium | 5 | 4 | transition metal | solid | – | Added to make strong steels (tools); vanadium pentoxide is a catalyst in making sulfuric acid. |
| 24 | Cr | chromium | 6 | 4 | transition metal | solid | – | Chrome plating gives shiny, corrosion-resistant surfaces; part of stainless steel. |
| 25 | Mn | manganese | 7 | 4 | transition metal | solid | – | Added to steel; manganese dioxide in batteries; potassium permanganate is a purple disinfectant. |
| 26 | Fe | iron | 8 | 4 | transition metal | solid | – | Most used metal – steel and cast iron; in hemoglobin it carries oxygen in the blood. |
| 27 | Co | cobalt | 9 | 4 | transition metal | solid | – | Cobalt blue in glass and ceramics; part of vitamin B12; magnets and rechargeable batteries. |
| 28 | Ni | nickel | 10 | 4 | transition metal | solid | – | Plating, stainless steel, coins; nickel–metal hydride rechargeable batteries. |
| 29 | Cu | copper | 11 | 4 | transition metal | solid | – | Excellent conductor of electricity – wires and cables; alloys bronze (with tin) and brass (with zinc). |
| 30 | Zn | zinc | 12 | 4 | transition metal | solid | – | Galvanizing iron and steel against rust; brass; batteries. |
| 31 | Ga | gallium | 13 | 4 | post-transition metal | solid | 3 | Melts in your hand (at about 30 °C); semiconductors and blue and white LEDs. |
| 32 | Ge | germanium | 14 | 4 | metalloid | solid | 4 | Semiconductor used in the first transistors; optical fibers and infrared optics. |
| 33 | As | arsenic | 15 | 4 | metalloid | solid | 5 | Its compounds are highly poisonous; used in semiconductors (gallium arsenide). |
| 34 | Se | selenium | 16 | 4 | nonmetal | solid | 6 | Used in solar cells and formerly in photocopiers; the body needs it in tiny amounts. |
| 35 | Br | bromine | 17 | 4 | halogen | liquid | 7 | The only nonmetal that is liquid at room temperature (a red-brown liquid); flame retardants. |
| 36 | Kr | krypton | 18 | 4 | noble gas | gas | 8 | Noble gas used in lamps and lasers; its name means "hidden". |
| 37 | Rb | rubidium | 1 | 5 | alkali metal | solid | 1 | Atomic clocks; catches fire by itself in air. |
| 38 | Sr | strontium | 2 | 5 | alkaline earth metal | solid | 2 | Gives fireworks a red color. |
| 39 | Y | yttrium | 3 | 5 | transition metal | solid | – | Phosphors and superconductors; named after the Swedish village of Ytterby. |
| 40 | Zr | zirconium | 4 | 5 | transition metal | solid | – | Cladding for nuclear fuel; cubic zirconia is a cheap diamond substitute. |
| 41 | Nb | niobium | 5 | 5 | transition metal | solid | – | Superconducting magnets (Large Hadron Collider, MRI scanners); added to steel. |
| 42 | Mo | molybdenum | 6 | 5 | transition metal | solid | – | Added to strong steels; a trace element that plants need. |
| 43 | Tc | technetium | 7 | 5 | transition metal | solid | – | Lightest element with no stable isotope and the first element made artificially; used in medical imaging. |
| 44 | Ru | ruthenium | 8 | 5 | transition metal | solid | – | Very hard metal – electrical contacts, catalysts; named after Ruthenia (Latin for Russia). |
| 45 | Rh | rhodium | 9 | 5 | transition metal | solid | – | One of the rarest and most expensive metals; car catalytic converters, shiny plating on jewelry. |
| 46 | Pd | palladium | 10 | 5 | transition metal | solid | – | Car catalytic converters; can soak up large amounts of hydrogen. |
| 47 | Ag | silver | 11 | 5 | transition metal | solid | – | Best conductor of electricity and heat of all metals; jewelry, coins, cutlery. |
| 48 | Cd | cadmium | 12 | 5 | transition metal | solid | – | Toxic; formerly used in nickel–cadmium batteries and yellow pigments. |
| 49 | In | indium | 13 | 5 | post-transition metal | solid | 3 | Transparent conductive coatings in touchscreens; so soft you can scratch it with a fingernail. |
| 50 | Sn | tin | 14 | 5 | post-transition metal | solid | 4 | Solder, tin-plated steel cans, bronze (with copper); in extreme cold it can crumble ("tin pest"). |
| 51 | Sb | antimony | 15 | 5 | metalloid | solid | 5 | Flame retardants; alloys with lead for car batteries. |
| 52 | Te | tellurium | 16 | 5 | metalloid | solid | 6 | Thin-film solar cells; added to alloys. |
| 53 | I | iodine | 17 | 5 | halogen | solid | 7 | Turns straight into violet vapor when heated (sublimes); iodine tincture disinfects wounds; iodized salt supports the thyroid. |
| 54 | Xe | xenon | 18 | 5 | noble gas | gas | 8 | Very bright lamps (car headlights, cinema projectors); ion engines of space probes. |
| 55 | Cs | caesium | 1 | 6 | alkali metal | solid | 1 | The second is defined using caesium atomic clocks; melts at only about 28 °C. |
| 56 | Ba | barium | 2 | 6 | alkaline earth metal | solid | 2 | Barium sulfate is a contrast agent for X-rays; gives fireworks a green color. |
| 57 | La | lanthanum | – | 6 | lanthanide | solid | – | Optical glass for camera lenses; batteries of hybrid cars; the lanthanides are named after it. |
| 58 | Ce | cerium | – | 6 | lanthanide | solid | – | Most abundant lanthanide; lighter flints, polishing glass. |
| 59 | Pr | praseodymium | – | 6 | lanthanide | solid | – | Strong magnets (together with neodymium); yellow pigment for ceramics. |
| 60 | Nd | neodymium | – | 6 | lanthanide | solid | – | Strongest permanent magnets – headphones, electric motors, wind turbines. |
| 61 | Pm | promethium | – | 6 | lanthanide | solid | – | The only lanthanide with no stable isotope; almost absent in nature; radioactive. |
| 62 | Sm | samarium | – | 6 | lanthanide | solid | – | Samarium–cobalt magnets that withstand high temperatures. |
| 63 | Eu | europium | – | 6 | lanthanide | solid | – | Red and blue phosphors; europium compounds glow under UV light in the security features of euro banknotes. |
| 64 | Gd | gadolinium | – | 6 | lanthanide | solid | – | Contrast agents for MRI scans. |
| 65 | Tb | terbium | – | 6 | lanthanide | solid | – | Green phosphors in fluorescent lamps and screens. |
| 66 | Dy | dysprosium | – | 6 | lanthanide | solid | – | Added to neodymium magnets in electric motors. |
| 67 | Ho | holmium | – | 6 | lanthanide | solid | – | Highest magnetic moment of any naturally occurring element; medical lasers. |
| 68 | Er | erbium | – | 6 | lanthanide | solid | – | Amplifies signals in optical fibers; colors glass pink. |
| 69 | Tm | thulium | – | 6 | lanthanide | solid | – | One of the rarest lanthanides; portable X-ray devices. |
| 70 | Yb | ytterbium | – | 6 | lanthanide | solid | – | Very precise atomic clocks; lasers. |
| 71 | Lu | lutetium | – | 6 | lanthanide | solid | – | Densest and hardest lanthanide; one of its radioactive isotopes is used to treat cancer. |
| 72 | Hf | hafnium | 4 | 6 | transition metal | solid | – | Control rods in nuclear reactors (absorbs neutrons); named after Copenhagen (Latin Hafnia). |
| 73 | Ta | tantalum | 5 | 6 | transition metal | solid | – | Capacitors in phones and computers; implants (it does not react with the body). |
| 74 | W | tungsten | 6 | 6 | transition metal | solid | – | Highest melting point of all metals (about 3,400 °C); filaments of old-style light bulbs; the symbol W comes from its other name, wolfram. |
| 75 | Re | rhenium | 7 | 6 | transition metal | solid | – | One of the rarest elements in Earth's crust; superalloys for jet engines. |
| 76 | Os | osmium | 8 | 6 | transition metal | solid | – | Densest element (about 22.6 g/cm³); very hard tips of fountain pens. |
| 77 | Ir | iridium | 9 | 6 | transition metal | solid | – | Extremely resistant to corrosion; spark plugs; an iridium-rich layer in rocks marks the asteroid impact from the time the dinosaurs died out. |
| 78 | Pt | platinum | 10 | 6 | transition metal | solid | – | Precious metal – jewelry; car catalytic converters; lab equipment. |
| 79 | Au | gold | 11 | 6 | transition metal | solid | – | Does not corrode and hardly reacts; jewelry, coins, gold bars, contacts in electronics. |
| 80 | Hg | mercury | 12 | 6 | transition metal | liquid | – | The only metal that is liquid at room temperature; formerly used in thermometers; its vapor is toxic. |
| 81 | Tl | thallium | 13 | 6 | post-transition metal | solid | 3 | Very toxic; named after the bright green line in its spectrum. |
| 82 | Pb | lead | 14 | 6 | post-transition metal | solid | 4 | Heavy, soft metal; car batteries, shielding against X-rays; toxic. |
| 83 | Bi | bismuth | 15 | 6 | post-transition metal | solid | 5 | Least toxic of the heavy metals; forms crystals with rainbow colors; used in stomach medicines. |
| 84 | Po | polonium | 16 | 6 | post-transition metal | solid | 6 | Highly radioactive; discovered by Marie and Pierre Curie and named after Poland. |
| 85 | At | astatine | 17 | 6 | halogen | solid (predicted) | 7 | Rarest naturally occurring element in Earth's crust; highly radioactive. |
| 86 | Rn | radon | 18 | 6 | noble gas | gas | 8 | Radioactive gas released from rocks; measured in homes because it harms the lungs. |
| 87 | Fr | francium | 1 | 7 | alkali metal | solid (predicted) | 1 | Extremely rare and radioactive (half-life about 22 minutes); named after France. |
| 88 | Ra | radium | 2 | 7 | alkaline earth metal | solid | 2 | Radioactive; Marie and Pierre Curie discovered it in uranium ore (pitchblende) from Jáchymov in Bohemia. |
| 89 | Ac | actinium | – | 7 | actinide | solid | – | Highly radioactive and glows blue in the dark; the actinides are named after it. |
| 90 | Th | thorium | – | 7 | actinide | solid | – | A possible nuclear fuel of the future; named after the Norse god Thor. |
| 91 | Pa | protactinium | – | 7 | actinide | solid | – | Very rare and radioactive; used only in research. |
| 92 | U | uranium | – | 7 | actinide | solid | – | Fuel for nuclear power plants; named after the planet Uranus. |
| 93 | Np | neptunium | – | 7 | actinide | solid | – | First element heavier than uranium (a transuranium element); named after the planet Neptune. |
| 94 | Pu | plutonium | – | 7 | actinide | solid | – | Nuclear fuel; power source for space probes and Mars rovers. |
| 95 | Am | americium | – | 7 | actinide | solid | – | Used in ionization smoke detectors. |
| 96 | Cm | curium | – | 7 | actinide | solid | – | Named after Marie and Pierre Curie; radiation source in instruments on Mars rovers. |
| 97 | Bk | berkelium | – | 7 | actinide | solid | – | Named after the city of Berkeley, California; used only in research. |
| 98 | Cf | californium | – | 7 | actinide | solid | – | Strong source of neutrons – starting up nuclear reactors, searching for oil and water underground. |
| 99 | Es | einsteinium | – | 7 | actinide | solid | – | Discovered in the debris of the first hydrogen bomb test (1952); named after Albert Einstein. |
| 100 | Fm | fermium | – | 7 | actinide | unknown | – | Also discovered in the debris of the 1952 hydrogen bomb test; named after Enrico Fermi. |
| 101 | Md | mendelevium | – | 7 | actinide | unknown | – | Named after Dmitri Mendeleev, who created the periodic table. |
| 102 | No | nobelium | – | 7 | actinide | unknown | – | Named after Alfred Nobel, founder of the Nobel Prizes. |
| 103 | Lr | lawrencium | – | 7 | actinide | unknown | – | Named after Ernest Lawrence, inventor of the cyclotron. |
| 104 | Rf | rutherfordium | 4 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after Ernest Rutherford. |
| 105 | Db | dubnium | 5 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after the town of Dubna in Russia. |
| 106 | Sg | seaborgium | 6 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after Glenn Seaborg. |
| 107 | Bh | bohrium | 7 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after Niels Bohr. |
| 108 | Hs | hassium | 8 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after the German state of Hesse. |
| 109 | Mt | meitnerium | 9 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after Lise Meitner. |
| 110 | Ds | darmstadtium | 10 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after the city of Darmstadt in Germany. |
| 111 | Rg | roentgenium | 11 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after Wilhelm Röntgen, discoverer of X-rays. |
| 112 | Cn | copernicium | 12 | 7 | transition metal | unknown | – | Synthetic, only a few atoms made; named after Nicolaus Copernicus. |
| 113 | Nh | nihonium | 13 | 7 | post-transition metal | unknown | 3 | Synthetic, only a few atoms made; named after Japan (Nihon). |
| 114 | Fl | flerovium | 14 | 7 | post-transition metal | unknown | 4 | Synthetic, only a few atoms made; named after the Flerov Laboratory in Dubna (and physicist Georgy Flerov). |
| 115 | Mc | moscovium | 15 | 7 | post-transition metal | unknown | 5 | Synthetic, only a few atoms made; named after the Moscow region. |
| 116 | Lv | livermorium | 16 | 7 | post-transition metal | unknown | 6 | Synthetic, only a few atoms made; named after Lawrence Livermore National Laboratory in California. |
| 117 | Ts | tennessine | 17 | 7 | halogen | unknown | 7 | Synthetic, only a few atoms made; named after the U.S. state of Tennessee. |
| 118 | Og | oganesson | 18 | 7 | noble gas | unknown | 8 | Synthetic, only a few atoms made; the heaviest known element, named after physicist Yuri Oganessian. |

## Spelling variants

Accept common spelling variants as correct answers: aluminium / aluminum, caesium / cesium, sulfur / sulphur. Also accept a small typo and remind the student of the correct spelling.

## Symbols that come from other names

Some symbols come from Latin (or German) names, which makes a good follow-up fact once the element has been guessed: Na – sodium (natrium), K – potassium (kalium), Fe – iron (ferrum), Cu – copper (cuprum), Ag – silver (argentum), Sn – tin (stannum), Sb – antimony (stibium), W – tungsten (wolfram), Au – gold (aurum), Hg – mercury (hydrargyrum), Pb – lead (plumbum).
