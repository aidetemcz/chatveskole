# Interdisciplinary Themes

Three interdisciplinary themes cut across all subject areas in the K–12 
curriculum, helping students see the world as connected and develop the 
dispositions, skills, and habits of mind that academic content alone 
cannot build:

- Caring for Self and Others (Whole-Child Wellbeing)
- An Inclusive and Informed Society
- Environmental Stewardship and Sustainability

Each theme has a defined structure: a description of its purpose, 
learning outcomes anchored at two grade-band benchmarks (end of 5th 
grade and end of 8th grade), connections to specific content areas 
where students build the underlying knowledge base, and explicit links 
to the seven core competencies. For each learning outcome, schools 
have access to suggested instructional steps and at least one 
illustrative example of evidence of learning.

These themes align with familiar U.S. frameworks: whole-child 
education (ASCD), social-emotional learning (CASEL), media literacy 
(NAMLE), civic education (C3 Framework), and environmental literacy 
(NAAEE / NGSS crosscutting concepts).

----------------

## Theme 1: Caring for Self and Others (Whole-Child Wellbeing)

The purpose of this theme is to help students apply the knowledge, 
skills, and dispositions they build across subjects to take active 
care of themselves and others — across all dimensions of wellbeing: 
physical, cognitive, emotional, social, and sense of purpose.

This theme contributes to creating a learning environment that meets 
students' developmental needs, builds resilience in the face of 
change, and engages students as co-creators of a positive class and 
school climate — including in digital spaces. It draws on and 
extends the social skills students develop in every classroom 
(collaboration, discussion, listening, asking for help) and connects 
academic content to self-understanding, planning, and decision-making. 
Outcomes can be reached through projects in school and out-of-school 
settings, student-led initiatives, and activities that strengthen 
positive school climate.

### End of 5th grade

**Students contribute to shaping a learning environment that supports 
their own needs and the needs of others in the school community.**

Content-area anchors: Health Education, Social Studies (elementary), 
Computer Science / Digital Literacy, English Language Arts.

This outcome positions the student as a co-creator of a supportive, 
stimulating learning environment where every member of the school 
community can develop their full potential. Students take an active 
role in building conditions that promote safety, belonging, and 
inclusion. They put what they have learned across content areas to 
use in support of their own learning and the learning of their peers.

**Students propose and try out activities that support their own 
wellbeing across each dimension.**

Content-area anchors: Health Education, Social Studies (elementary), 
Computer Science / Digital Literacy, Physical Education.

This outcome focuses on students' active and intentional care for 
their own wellbeing across physical, emotional, social, cognitive, 
and sense-of-purpose dimensions. Students apply self-regulation 
strategies, build resilience for problem-solving and overcoming 
obstacles, and use practical tools — balancing activity and rest, 
practicing healthy habits, expressing needs, asking for help, using 
positive self-talk, exercising effort and willpower, and acting 
ethically in person and online.

**Working with others, students propose and try out activities that 
support the wellbeing of everyone in the school community.**

Content-area anchors: Health Education, Social Studies (elementary), 
Computer Science / Digital Literacy.

This outcome focuses on students' co-creation of a school environment 
where every member's basic needs are met. Students build respectful 
relationships, support a positive climate in physical and digital 
spaces, and develop dialogue, listening, and supportive communication 
skills. With peers, they try out small-scale actions that improve 
wellbeing — emotional, social, physical, and sense-of-purpose — in 
their classroom and broader school community.

### End of 8th grade

**Students actively co-shape the learning environment to meet their 
own needs and the needs of others in the school community.**

Content-area anchors: Health Education, Health & Safety, English 
Language Arts, Computer Science / Digital Literacy.

This outcome supports students in becoming active co-creators of a 
learning environment where every member can develop physically, 
cognitively, emotionally, socially, and in their sense of purpose, 
and contribute to others' wellbeing. Students apply what they've 
learned across subjects to support their own wellbeing and the 
wellbeing of others — in academic work, classroom relationships, 
and digital spaces. The outcome covers a range of skills: building 
safety, meeting emotional needs, managing stress, sustaining 
respectful relationships, and developing a values framework and 
sense of purpose.

**Students plan, carry out, and evaluate activities that support 
their own wellbeing across each dimension.**

Content-area anchors: Health Education, Health & Safety, Physical 
Education, Civics / Social Studies, Computer Science / Digital 
Literacy.

This outcome focuses on students' active, goal-directed care for 
their own wellbeing across all five dimensions, in the context of 
their academic work. Students apply self-regulation strategies and 
develop resilience: practicing healthy habits, balancing activity 
and rest, expressing needs, asking for help, using positive 
self-talk and effort, and applying ethical principles — including 
in digital environments.

**Working with others, students plan, carry out, and evaluate 
activities that support the wellbeing of everyone in the school 
community.**

Content-area anchors: Health Education, Health & Safety, Civics / 
Social Studies, Computer Science / Digital Literacy.

This outcome focuses on the skills needed to support every community 
member's needs. Students actively support peer learning across 
subjects, build respectful relationships in person and online, and 
develop dialogue, listening, and supportive communication skills 
in school and the broader community.

----------------

## Theme 2: An Inclusive and Informed Society

The purpose of this theme is to develop students' ability to navigate 
everyday life thoughtfully, make decisions both ordinary and 
consequential, and critically reflect on their own attitudes and 
choices — with a clear sense of responsibility for the impact of 
those choices on themselves and others.

Through this theme, students gradually come to understand the 
complexity, diversity, and interconnectedness of today's world. 
They are encouraged to reflect on what shapes their own attitudes, 
reasoning, and decisions. They learn that they can positively 
influence their own lives and the communities they belong to — at 
personal, school, local, and global levels — while respecting equal 
opportunity, human rights, and the dignity of every person.

The theme gives students opportunities, through both real and 
modeled situations, to: (a) build a confident, safe relationship 
with media and communication technologies, (b) develop an open, 
non-judgmental stance toward diversity in their own community and 
in the world, (c) recognize shared narratives and identify 
prejudgment and stereotypes in contemporary communication. It also 
gives students opportunities to build resilience against manipulation 
and apply democratic decision-making principles in everyday life, 
including reflective and intentional use of media.

It is important that students understand the role media play in 
their lives, evaluate sources critically, recognize manipulation 
techniques, and see the world as a diverse, interconnected space 
where equal opportunity and dignified relationships matter.

### End of 5th grade

**Students explore and reflect on the diversity and interconnectedness 
of the world.**

Diversity and interconnectedness are realities students live in, and 
the goal is to help them see these as opportunities for their future. 
Students should perceive diversity positively from an early age and 
reflect on their own ideas about others and the world based on their 
everyday experiences.

This outcome is important so students can experience, observe, and 
reflect on the diversity of the world and become prepared for 
respectful life within it. Students notice diversity among people 
and cultures, discover the world's interconnectedness, and reflect 
on what diversity and interconnectedness bring to themselves, their 
class, and their community. They experience diversity first by 
sharing their own stories and experiences with peers, looking for 
what they share in common, and recognizing what makes each person 
unique. The outcome strengthens students' sense of self-worth and 
respect for others. Students encounter situations that surface 
diversity in many forms — age, gender, language background, 
ethnicity, ability, family structure, housing, and economic 
circumstances.

Students also see today's world as an interconnected whole. They 
explore connections starting from what they know — what they use, 
experience, and observe — and trace links between local and global 
events. Understanding interconnectedness prepares students to 
navigate an increasingly complex world, recognize good responses to 
different situations, see their own role in the world, and make 
choices that support both their own flourishing and positive change.

**Students critically evaluate the content and intent of media 
messages using concrete examples.**

This outcome helps students understand that today's world offers an 
enormous range of information, which in turn shapes how they see the 
world. The meaning, credibility, and value of information depends 
heavily on its source. The aim is to build students' awareness of 
where information comes from and to deepen their reflection on the 
choices behind their media consumption. Students learn to reflect on 
their own media use (for example, by keeping a media-use log), 
evaluate which media they use most and least and why, identify what 
activities they associate with each medium (school, communication, 
entertainment), recognize which media they cannot imagine life 
without and why, and identify which sources they rely on most. 
Students distinguish among types of messages — recognizing 
advertising and fiction from news and opinion — and evaluate the 
emotional charge of specific messages. In a simple text, they 
identify facts, trace their sources, and distinguish facts from 
opinions. This is the foundation of safe, informed media use. 
Students also learn to evaluate source reliability, manage their 
digital identity, and recognize the permanence of online actions.

**Students give examples, drawn from their own experience, of how 
media use can shape their attitudes or those of their peers toward 
a topic.**

Through this outcome, students recognize how media messages can shift 
attitudes — their own and others' — on specific issues. They reflect 
on personal experiences, identify the messages and channels involved, 
and consider what effect those messages had.

### End of 8th grade

**Students assess opportunities and risks of an increasingly 
interconnected world for themselves and for society.**

This outcome leads to a deeper understanding of the world as an 
interconnected whole, with students examining their own role in it. 
They recognize that interconnectedness brings opportunities — travel, 
technology, study and work options, exchange of cultural traditions — 
and risks — increased consumption, cybersecurity threats. Students 
weigh these opportunities and risks for themselves and for society. 
They recognize and investigate why these opportunities are not 
equally available to everyone.

In a rapidly changing, interconnected world, students need to 
understand the phenomena driving that change and their own future 
within it.

**Students recognize and explain the rhetorical and design choices 
media use to shape how a topic is perceived.**

Through this outcome, students recognize that media offer both 
topics to think about and implicit guidance on how to think about 
them. Media persuade through arguments (including logical fallacies), 
emotional appeals, and manipulation. Students learn to recognize 
the rhetorical and design choices used in messaging — a foundational 
skill for critical media engagement. Behind any media message there 
are intentions; students learn to infer these from the choice of 
language, the selection of facts, and the framing of perspectives.

**Students recognize attitudes, stereotypes, and bias in media 
messages and propose ways to limit the risks of their spread.**

Through this outcome, students gain the skills to critically evaluate 
the judgments embedded in media messages. Media offer not just 
topics but framings — placing messages in specific contexts, 
selecting evidence, presenting attitudes. Within messages, students 
can find both explicit and implicit judgments about people, groups, 
historical periods, society, values, and more. By critically 
examining context, language choices, and the framing of facts, 
students learn to recognize these judgments — a core skill for 
critical media engagement.

**Students consider the needs of people in difficult circumstances 
and propose ways to strengthen equal opportunity and community 
cohesion locally and globally.**

This outcome enables students to recognize, through specific human 
stories and current events, social and economic inequalities among 
people, regions, and countries. Students learn to understand 
situations of hardship, what they involve, and what needs they 
create. They identify examples of inequality from their own 
observation or learning — differences in financial resources, 
access to clean water and food, education, healthcare, leisure, 
and travel. They consider what defines quality of life and how 
they envision it themselves. Understanding inequality leads them 
to reflect on the causes of poverty, the protection of basic human 
rights, and the various forms of discrimination people may face — 
based on age, gender, ethnicity or background, language, cultural 
differences, ability, or socioeconomic status.

Students discuss with others what specific examples of inequality 
mean for how society functions and how it might develop, and why 
ensuring equal opportunity matters for a sustainable future where 
everyone can live with dignity. They learn about constructive 
responses for people facing hardship and discrimination. With 
others, they propose actions that can strengthen equal opportunity, 
fairness, and community cohesion. Students are encouraged to 
consider these issues from local to global perspectives.

This outcome connects to current world issues and draws on multiple 
content areas. It supports the development of attitudes, values, 
and capacities — empathy, solidarity, respect, fairness — that are 
foundations for active engagement in a more just and peaceful world.

**Students critically evaluate how democratic principles are 
practiced at school and propose ways to strengthen democratic 
processes.**

This outcome focuses on students' understanding of democratic 
principles and how they are applied. Students examine school 
decision-making, propose criteria for assessment, and become 
critical observers of democratic culture in their own community. 
The first step is to identify what to assess and why, with student 
input. Students then observe: who makes decisions and how; whether 
processes are transparent; whether students can participate; 
whether diverse views are respected; whether listening is genuine. 
Group work and links to actual school life make this outcome 
authentic. It develops critical thinking, supports inquiry-based 
learning (students investigate democracy in their immediate 
environment), and leads to proposals for change.

This outcome supports students in seeing themselves as agents in 
the communities where they live, with a legitimate interest in 
shaping school life. It also sets reasonable boundaries and guides 
students toward proposing solutions. It builds belonging, 
self-confidence, and a sense of agency — the belief that "I can 
influence and change something." It contributes to democratic 
culture in school and is well-suited to many subjects, advisory 
periods, and whole-school activities.

**Students take part in actions that strengthen democratic culture 
at school, in the local community, and beyond.**

The aim is for students to apply democratic principles in different 
ways and contexts — equality, respect for others, tolerance for 
diversity, freedom of thought and expression, and participation in 
decision-making. This can take the form of voting, seeking 
compromise or consensus, surveys, or polls. What matters is that 
students decide or co-decide on issues that affect them, propose 
their own questions for discussion, and engage with situations where 
solutions are not handed down by authority.

Students choose — individually or collectively — short-term or 
ongoing activities that contribute to the common good or help 
specific people: for example, a student-government initiative, work 
on a school code of conduct, a peer-support program, organizing 
school events, intergenerational activities, or learning events for 
the local community. Activities can be civic, charitable, social, 
environmental, artistic, or athletic — held in the classroom, the 
school, or the wider community. Because this outcome is grounded in 
direct experience, reflection is an essential part of it.

This outcome supports the role of the engaged citizen. The actions 
students choose and carry out for the benefit of others build 
self-confidence, sense of agency, and belonging. They help students 
experience that society — including the school community — is for 
everyone, and that they can have a positive influence on the world 
around them. Students learn to take responsibility and develop 
autonomy. The outcome is integrative: it draws on collaboration, 
communication, critical and creative thinking, work with media 
messages, and project-management skills. It is well-suited to group 
work, advisory periods, and whole-school activities and projects.

----------------

## Theme 3: Environmental Stewardship and Sustainability

The purpose of this theme is to equip students with the capacity to 
observe, understand, and act in support of life on our planet — at 
the personal, civic, and (eventually) professional levels. The theme 
includes building and reflecting on students' relationship to their 
environment — natural, social, cultural, and built. It connects 
environmental literacy to other dimensions of sustainability and 
develops understanding of how environmental, social, economic, and 
cultural dimensions of sustainability connect across space and time. 
It supports students' ability to investigate sustainability problems 
independently, motivates active engagement, and builds the skills 
needed for individual and collective action.

### End of 5th grade

**Students propose how the place where they live should look in the 
future and how that vision could be supported.**

Through this outcome, students develop a sense of place: an 
understanding of how natural and social elements connect in their 
environment and how they change over time. The outcome combines 
students' multi-dimensional view of their place with their capacity 
to imagine the future, voice possible concerns about how it may 
develop, and articulate hopes and visions for their community. The 
ability to think about the future is one of the basic conditions 
for caring about one's community and engaging in public conversation 
about its development. Students need opportunities to speak openly 
about concerns — for example, how climate-related changes (drought, 
more frequent flooding, stress on local forests) affect their world. 
The capacity to articulate a positive vision for their community 
strengthens hope that current problems can be addressed. Spending 
some instructional time outdoors, investigating the environment 
firsthand, is essential.

**Students plan and carry out, together with peers, actions that 
strengthen