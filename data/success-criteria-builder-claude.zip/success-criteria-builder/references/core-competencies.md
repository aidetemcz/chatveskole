# Core Competencies and Transferable Skills

Core competencies are the integrated knowledge, skills, dispositions,
and habits of mind that prepare students for academic success, civic
participation, career readiness, and lifelong learning. They are not
content-area-specific; they cut across disciplines and develop over
the course of a student's K–12 experience and beyond.

These competencies align with widely used U.S. frameworks, including:
- CASEL's five SEL competencies (self-awareness, self-management,
  social awareness, relationship skills, responsible decision-making),
- the 4Cs from the Partnership for 21st Century Learning (critical
  thinking, communication, collaboration, creativity),
- ISTE Standards for Students (digital literacy and citizenship),
- state and district Portrait-of-a-Graduate documents.

## Why core competencies matter

The purpose of K–12 education is to equip every student with these
competencies at a developmentally appropriate level so they are
prepared for the next stage of their learning and life. Building
these competencies is a long arc that begins in early childhood and
continues through and beyond high school. What students reach by
the end of 8th grade — and again by graduation — is not an endpoint
but a foundation for college, career, and engaged citizenship.

Competencies do not stand in isolation. They overlap, reinforce one
another, and are best developed across subjects rather than within
any single class period. Every part of the school experience — content
instruction, projects, discussions, assessments, classroom routines —
contributes to building them. Content is the vehicle; the competencies
are the destination.

## The seven core competencies

### 1. Learning to learn (metacognition and learner agency)

By the end of middle school, students:
- choose and apply effective learning strategies; plan, monitor, and
  manage their own learning; and show willingness to keep learning
  throughout life,
- locate, evaluate, organize, and use information from multiple sources
  to support their learning, creative work, and everyday decisions,
- use academic vocabulary, symbols, and representations accurately,
  connect ideas across subjects, and build a coherent understanding
  of the world,
- observe, ask questions, and conduct simple investigations; compare
  results, think critically about them, and apply what they learn,
- understand the purpose of their learning, monitor their own progress,
  identify obstacles, set goals for improvement, and reflect on outcomes
  with peers and teachers.

### 2. Critical thinking and problem-solving

By the end of middle school, students:
- recognize problems in academic and real-world settings, identify
  underlying causes, and plan a thoughtful approach to solving them,
- gather and evaluate information from multiple sources, look for
  patterns and contradictions, and persist through setbacks,
- choose appropriate strategies — logical, mathematical, empirical —
  and apply them independently,
- test their solutions, transfer effective strategies to new problems,
  and track their own progress,
- think critically, make reasoned decisions, defend their reasoning
  with evidence, and take responsibility for the outcomes.

### 3. Communication

By the end of middle school, students:
- express ideas clearly, coherently, and respectfully in speaking and
  writing for a range of audiences and purposes,
- listen actively, respond thoughtfully, participate constructively in
  discussion, and support claims with evidence,
- interpret texts, visuals, data displays, and multimedia sources
  critically and use them to deepen their own thinking,
- use appropriate digital tools to communicate effectively and
  responsibly,
- use communication skills to build positive relationships and
  collaborate with others.

### 4. Collaboration and social-emotional skills

By the end of middle school, students:
- contribute productively to group work, help establish team norms,
  and take on roles that strengthen the group's effort,
- treat peers with respect and empathy, build a positive group climate,
  offer help, and ask for help when needed,
- contribute to small-group and whole-class discussion, value diverse
  perspectives, and learn from others,
- develop a positive sense of self, regulate their emotions and
  behavior, and pursue goals with confidence and self-respect.

### 5. Civic engagement and responsible citizenship

By the end of middle school, students:
- respect the beliefs and humanity of others, recognize injustice, and
  stand against bullying and other forms of harm,
- understand the basic principles behind laws, rules, and democratic
  norms, and know their rights and responsibilities at school and in
  the community,
- make responsible decisions, offer help in difficult or emergency
  situations, and act with care for others' safety and well-being,
- value cultural and historical heritage, engage with the arts, and
  participate actively in their school and community,
- understand basic environmental issues, make choices that support
  health and sustainability, and act as responsible stewards of
  shared resources.

### 6. Career readiness and workplace skills

By the end of middle school, students:
- use materials, tools, and equipment safely and effectively; follow
  procedures; meet commitments; and adapt to changing conditions,
- evaluate the quality, usefulness, and broader impact of their work,
  including its effects on health, others, and the environment,
- connect what they're learning to possible future paths, make informed
  decisions about courses and interests, and explore career options,
- understand basic concepts of entrepreneurship — what it takes to turn
  an idea into action, including risk, planning, and follow-through.

### 7. Digital literacy and responsible technology use

By the end of middle school, students:
- use everyday digital devices, apps, and platforms confidently for
  learning, school life, and civic participation; choose the right
  tool for the task,
- find, evaluate, manage, and share information and digital content
  appropriately for the situation and purpose,
- create and edit digital content, combining text, images, audio,
  and video to communicate effectively,
- use technology to streamline work, automate routine tasks, and
  improve the quality of their output,
- understand the role of technology in society, evaluate its benefits
  and risks, and stay current with new tools,
- protect their own and others' privacy, safety, and well-being online;
  recognize harmful content and behavior; and act ethically when
  collaborating, communicating, or sharing in digital spaces.