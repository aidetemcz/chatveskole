# Key to Writing Learning Objectives with the New Taxonomy

This key supports writing learning objectives with *The New Taxonomy of Educational Objectives* by Robert J. Marzano and John S. Kendall (2nd ed., Corwin Press, 2007), in the style used by AI for Children (AI dětem). It is the U.S. adaptation of our Czech key.

The book has no verb list like Bloom's taxonomy. The verbs in this key were derived from the task descriptions in chapters 4 and 5 of the book. The style rules, the learning context, and the output formats are ours. Do not use Bloom's taxonomy or its levels (remember, apply, create…).

---

## 1. Objective and learning context

A **learning objective** says what students will do with a piece of knowledge. It has two parts:

- the **process**: what students do in their heads or with their hands (compare, explain, perform, set a goal…),
- the **knowledge** they do it with (a concept, a principle, a procedure, a skill).

A topic on its own ("encryption") is not an objective. "Students will explain the roles of the algorithm and the key in encryption" is.

A **learning context** is the specific situation, material, or topic in which students work toward the objective. The objective stays the same and the contexts change. The same objective can carry across several lessons, units, or even years. This keeps the objective short and general, while the context carries the specifics.

> **Objective:** Students will use systematic debugging to fix a broken game. **Learning contexts:** a Scratch game that sometimes crashes · a web game where a button doesn't respond

> **Objective:** Students will compare two arguments on a debatable issue based on the quality of their evidence. **Learning contexts:** Should cell phones be allowed in classrooms? · Should our town build a new skate park or a new library?

The book works with *educational objectives*. Conditions and performance thresholds (how many, how well) do not go in the objective. They belong in the learning context and the success criterion.

---

## 2. The model: three domains × six levels

Every objective sits where one **knowledge domain** (what kind of knowledge students work with) meets one **level** (how they process it).

### 2.1 Knowledge domains

| Domain | What belongs here | Types |
| :---- | :---- | :---- |
| **Information** (declarative knowledge) | Knowing *what* is true. It cannot be performed. | **Details:** vocabulary terms, facts, time sequences. **Organizing ideas:** generalizations, principles. |
| **Mental procedures** | Knowing *how* to do something in your head. | **Skills:** single rules, algorithms, tactics; with practice they become automatic. **Processes (macroprocedures):** complex procedures such as writing an essay, designing an app, or debugging a program; they need conscious control each time. |
| **Psychomotor procedures** | Physical procedures. They are learned like mental procedures: first as a description, then refined through practice, and finally automatic. | **Skills:** foundational abilities (finger dexterity) and simple combinations (shooting a basketball). **Processes:** complex combinations (touch typing, soldering, playing a team sport). |

**Deciding question:** Can it be *performed*? Yes: it is a procedure (mental or psychomotor). No, it can only be known, recognized, or explained: it is information.

**Careful:** A procedure that students can so far only describe is, for them, information. Describing a procedure shows knowledge *about* it. Only performing it shows mastery.

One concept often spans several domains. "Binary numbers" is information (why computers use them) and a mental procedure (converting a number). Each objective, however, targets **one** domain. Name the domain for each objective separately.

**The domain is set by the knowledge students work with, not by what they do with it.**

- When students *explain* a procedure (integrating) or look for errors in how it was performed, the domain is still the **procedure**. "Students will explain the principle of touch typing…" belongs to psychomotor procedures.
- When, at level 4, students use a principle as the basis for an experiment or a decision, the domain is **information** (for example, an experiment on photosynthesis).
- At levels 5 and 6, name the domain of the knowledge students are thinking about. Setting a goal for improving at debugging is therefore a mental procedure.

### 2.2 Levels and processes

The levels are not ordered by difficulty but by how much conscious control students need. The difficulty of an objective comes from the complexity of the knowledge and the context, not from the level. A kindergartner can work at level 5 or 6.

**Level 1 Retrieval** · processes: recognizing, recalling, executing

*What it is:* Students retrieve knowledge in the form in which they learned it. They recognize a correct statement, state it themselves, or carry out a learned procedure. Retrieval moves knowledge from long-term memory into working memory, where students can work with it consciously.

*How to check it:* With a multiple-choice question, a question about what was taught, or a task in which students perform a procedure without significant errors.

**Level 2 Comprehension** · processes: integrating, symbolizing

*What it is:* Students organize knowledge into a whole and connect it with what they already know. They separate what is essential from what is not and express the core in their own words or in a representation. Comprehension turns knowledge into a compact form that can be stored in long-term memory.

*How to check it:* With a summary in students' own words, a description of what is essential, or, for a procedure, a description of the steps and why they come in that order. Or with a diagram or graph that represents the knowledge accurately.

**Level 3 Analysis** · processes: matching, classifying, analyzing errors, generalizing, specifying

*What it is:* Students use what they know to work out something new that they did not know before. They compare, classify, look for errors, generalize, and think through consequences. At this level they do these things deliberately and rigorously, and in doing so they change and refine their knowledge.

*How to check it:* With a task that cannot be solved by repeating what was taught: a comparison, sorting into a category, finding errors, inferring a rule from examples, or predicting what will happen if… Students justify their reasoning.

**Level 4 Knowledge Utilization** · processes: decision making, problem solving, experimenting, investigating

*What it is:* Students use what they know and can do to accomplish a specific task. They choose between options, solve a problem, test a hypothesis, or use sources to investigate why something happened or what would happen if… Knowledge becomes useful in a specific task.

*How to check it:* With a practical task or project that cannot be done without the knowledge. Students reach a result and explain how the knowledge helped them get there.

**Level 5 Metacognition** · processes: specifying goals, process monitoring, monitoring clarity, monitoring accuracy

*What it is:* Students manage their own learning. They set a goal and a plan and monitor and evaluate whether they have the knowledge and skills they need to reach it. Metacognition is possible only when students care enough about reaching the goal (the self-system).

*How to check it:* With a goal and plan that students write down or share in another way, with an ongoing description of what is working and what they will change, or with a self-assessment in which they name precisely what they don't understand and use a source to confirm what they have right.

**Level 6 Self-System** · processes: examining importance, examining efficacy, examining emotional response, examining motivation

*What it is:* Students examine what draws them toward learning or holds them back. They consider how important the content is to them, whether they believe they have the ability and resources to learn it, what emotions it brings up, and which of these affects their motivation most. The self-system is made of the attitudes, beliefs, and emotions that decide whether students engage in learning and how much energy they put into it.

*How to check it:* With a reflection in which students name their attitude, explain what it is based on, and judge how reasonable their thinking is. The goal is to understand the attitude, not to change it. The quality of the reasoning is assessed, never the amount of motivation.

---

## 3. How to write an objective

### 3.1 Frame

> **Students will** + **verb** (process) + **knowledge** [+ essential condition]

The book uses "The student will be able to…". We drop "be able to" and go straight to the verb. If a school requires the SWBAT frame, add "be able to" without changing the rest.

### 3.2 Style rules

1. **Start with "Students will" and an observable verb** that names a complete performance: state, explain, draw, compare, choose, evaluate. Use an ongoing verb only for an ongoing activity: "monitor".
2. **Don't write "be able to," "can," "know how to," or "learn to."** Don't use unobservable verbs: know, understand, appreciate, realize, grasp, become familiar with, be aware of.
3. **One main verb.** A second verb only when it is part of the same performance: "critique … and suggest an improvement," "explain the principle … and describe its advantages." Never three.
4. **Keep it short.** About 15 words, not counting a long concept name. No filler ("in the context of," "based on acquired knowledge").
5. **General, not a scenario.** The specific situation, material, tool, or story goes in the learning context. Write "a broken game," not "a game that sometimes crashes"; "data," not "our class survey data." The objective does keep the **essential condition**, which defines the process itself and holds in general: the basis of a comparison ("based on the substances used"), the condition in specifying ("when the image size increases"), the criteria in decision making ("based on criteria set in advance"). Test: Would the process change if I left it out? Yes: it's a condition and stays in the objective. No, only the situation would change: it's a scenario and goes in the context.
6. **Name the knowledge.** The objective must make sense on its own. A short phrase is enough: "debugging," "encryption," "touch typing."
7. **Anchor in specifics where that is the core of the process:** "using a specific example," "for their own needs," "a specific program."
8. **"Their own" belongs only at levels 5 and 6**, where the objective is about students' own knowledge, goal, or attitude ("their own claims," "their ability," "for their own needs"). At levels 1–4 leave it out ("the debugging process," not "their own debugging process").
9. **A quality standard only where it is part of the process:** "without significant errors" for executing, "based on criteria set in advance" for decision making. Otherwise quality is carried by the success criterion.
10. **The student's perspective, not the teacher's.** Not "The teacher will introduce…" but "Students will explain…".
11. **One objective = one process = one domain.**

### 3.3 Before and after (real revisions from our practice)

| Original | Revised | What changed |
| :---- | :---- | :---- |
| Students will be able to draw a flowchart of their own debugging process. | Students will draw a flowchart of the debugging process. | dropped "be able to" and the unnecessary "their own" |
| Students will be able to judge how important understanding encryption is for them and evaluate whether their reasoning makes sense. | Students will evaluate the importance of knowing about encryption for their own needs. | one verb, shorter |
| Students will be able to find the mistake made by a classmate who changes several things at once. | Students will critique a classmate's debugging process and suggest an improvement. | scenario moved to the context |
| Students will set a goal and plan for getting better at debugging programs. | Students will set a goal and plan for improving their debugging of a specific program. | anchored in specifics |
| Students will choose appropriate security for sharing our class data based on criteria set in advance. | Students will choose appropriate security for sharing data based on criteria set in advance. | more general |
| Students will use systematic debugging to fix a game that sometimes crashes. | Students will use systematic debugging to fix a broken game. | more general |
| Students will evaluate the accuracy of the claim "a padlock in the browser means the website is safe." | Students will evaluate the accuracy of the claim "this password is secure" using a specific example. | shorter claim, anchored in an example |
| Students will explain why fingers return to the home row in touch typing. | Students will explain the principle of touch typing and describe its advantages. | the whole instead of one detail |
| Students will test experimentally whether short daily practice or one long session works better for learning touch typing. | Students will test experimentally which way of practicing touch typing works best for them. | shorter; the hypothesis moves to the context |

---

## 4. Processes: patterns and verbs

Each pattern follows the general form of objectives in the book (figure 5.1). Replace [knowledge] with the specific concept. The verbs are a guide only. **The process is set not by the verb but by what the task actually asks students to do** (see section 6).

### Level 1: Retrieval

| Process | What students do | Pattern | Verbs |
| :---- | :---- | :---- | :---- |
| **Recognizing** | Confirm whether statements about what was taught are correct. They don't have to produce them. | Students will recognize correct statements about [knowledge]. | recognize, select the correct, identify from options, mark |
| **Recalling** | State what was taught. For a procedure, describe its nature and purpose, not how to perform it. | Students will state [features, examples, purpose] of [knowledge]. | state, list, name, define, describe |
| **Executing** | Perform a procedure without significant errors. They don't need to know why it works. **Procedures only.** | Students will [perform the procedure] (without significant errors). | perform, calculate, convert, write, fix, set up, carry out |

### Level 2: Comprehension

| Process | What students do | Pattern | Verbs |
| :---- | :---- | :---- | :---- |
| **Integrating** | Express the core of the knowledge in their own words and separate essential from nonessential. For a principle, describe the relationship between its variables; for a procedure, the logic of the steps and their order. | Students will explain [the principle / structure / logic of the steps] of [knowledge]. | explain, summarize, describe in their own words, distinguish essential from nonessential |
| **Symbolizing** | Represent the knowledge accurately (diagram, graph, flowchart, model), capturing its essential elements. | Students will represent [knowledge] [as a form]. | represent, draw, diagram, graph, create a flowchart / concept map, build a model |

### Level 3: Analysis

| Process | What students do | Pattern | Verbs |
| :---- | :---- | :---- | :---- |
| **Matching** | Identify important similarities and differences based on essential features. | Students will compare [A] and [B] based on [basis]. | compare, contrast, identify similarities and differences |
| **Classifying** | Place the knowledge in a superordinate category, or identify its subcategories, and justify the choice. | Students will classify [knowledge] into [category] and justify the classification. | classify, sort, categorize, organize into categories |
| **Analyzing errors** | For information, judge whether a statement is accurate and supported. For procedures, find errors in how they were performed. | Students will evaluate the accuracy of claims about [knowledge]. / Students will identify errors in [performance of the procedure]. | evaluate the accuracy, detect, identify errors, critique a process and suggest an improvement |
| **Generalizing** | Infer a new general rule from specific examples or data and defend it. | Students will infer a general rule about [knowledge] from [examples / data]. | infer, formulate a rule, draw a conclusion |
| **Specifying** | Use a rule or principle to work out what will happen under certain conditions. **Not for details.** | Students will predict how [knowledge] will play out when [condition]. | predict, deduce the consequence, determine what will happen if… |

### Level 4: Knowledge Utilization

Each process has two variants: the knowledge is either **used** to accomplish the task, or the task is **about** the knowledge itself. For procedures, the task must be built so that students cannot complete it without the procedure.

| Process | What students do | Pattern | Verbs |
| :---- | :---- | :---- | :---- |
| **Decision making** | Choose among options that at first look similar, based on criteria. | Students will choose [the best option] based on [criteria]. | choose, decide, select the best, recommend |
| **Problem solving** | Reach a goal that is blocked by an obstacle or constraint. | Students will use [knowledge] to solve [problem]. | solve, fix, develop a solution, adapt |
| **Experimenting** | Form a hypothesis and test it through observation or measurement. | Students will test experimentally [hypothesis about knowledge]. | test experimentally, design and conduct an experiment |
| **Investigating** | Look for an answer to a question about the past, present, or future (What happened? Why? What would happen if…?) using sources and other people's claims, and support the conclusion with arguments. | Students will use sources to investigate [question]. | investigate, find and evaluate sources, defend a conclusion |

### Level 5: Metacognition

| Process | What students do | Pattern | Verbs |
| :---- | :---- | :---- | :---- |
| **Specifying goals** | Set a specific goal and a plan (steps, time frame, resources). | Students will set a goal and plan for improving in [knowledge]. | set a goal and plan, plan |
| **Process monitoring** | While working, track how they are moving toward the goal they set, and adjust. | Students will monitor progress toward their goal during [activity]. | monitor, check in on progress |
| **Monitoring clarity** | Name precisely what they don't understand or aren't sure about. | Students will identify what is unclear to them about [knowledge]. | identify what is unclear, name points of confusion |
| **Monitoring accuracy** | Check their own claims or procedure against an outside source. | Students will verify the accuracy of their own claims about [knowledge] against a credible source. | verify, check against a source, confirm with evidence |

### Level 6: Self-System

| Process | What students do | Pattern | Verbs |
| :---- | :---- | :---- | :---- |
| **Examining importance** | Determine how important the knowledge is to them and examine their reasons. | Students will evaluate the importance of [knowledge] for their own needs. | evaluate the importance, determine how important |
| **Examining efficacy** | Judge how much they believe they have the ability and resources to improve, and what that belief rests on. | Students will evaluate their ability to improve in [knowledge]. | evaluate their ability |
| **Examining emotional response** | Name the emotions they associate with the knowledge and their cause. The goal is to understand the emotion, not to change it. | Students will identify the emotions they associate with [knowledge] and their cause. | identify emotions, identify the cause |
| **Examining motivation** | Weigh importance, efficacy, and emotions, and identify what affects their motivation most. | Students will identify what most affects their motivation to improve in [knowledge]. | identify what affects motivation |

---

## 5. What applies to which domain

| Level | Information | Mental and psychomotor procedures |
| :---- | :---- | :---- |
| **1** | Recognizing and recalling only. **There is no executing.** | Recognizing and recalling show only knowledge *about* the procedure. Real mastery shows in **executing**, so prefer it for procedures. |
| **2** | Integrating: essential vs. nonessential; for a principle, the relationship between variables. Integrating details only when they have structure (for example, a sequence of events). Symbolizing: diagram, graph. | Integrating: the steps, their order, and their logic. Symbolizing: flowchart, process diagram. |
| **3** | Analyzing errors: accuracy and support of claims. **Specifying only for generalizations and principles**, not for details. | Analyzing errors: errors in performance. Classifying skills: superordinate category only. Specifying: how the procedure changes under different conditions. |
| **4** | The knowledge serves as the basis or criterion for a decision or solution. | The procedure is a tool without which the task cannot be done. In psychomotor decision making, the choice is usually about the most suitable skill. |
| **5** | Process monitoring: how understanding develops over time. Monitoring clarity and accuracy fit well. | Process monitoring: in real time while performing. Specifying goals and process monitoring fit well. |
| **6** | The same for all domains. | The same for all domains. |

---

## 6. Verbs that mislead

In the New Taxonomy, the level is decided by what the task actually asks students to do, not by the verb alone. These verbs appear at several levels:

| Verb | Level 1 | Higher level |
| :---- | :---- | :---- |
| **explain** | repeats an explanation that was taught (recalling) | expresses the core in their own words and separates the essential (integrating, level 2) |
| **give examples** | **default reading:** examples that were taught or that students know from everyday life (recalling) | only when the wording explicitly asks for new examples that were not taught, which students must generate from a general rule (level 3) |
| **answer questions** | answers from memory (recalling), or reads the answer from given data using a learned procedure (executing) | the answer requires a comparison, a conclusion, or a prediction (level 3) |
| **recognize / identify** | selects or confirms a statement that was taught (recognizing) | detects an error, manipulation, or misinterpretation in new material (analyzing errors, level 3) |
| **determine / judge** | confirms a statement that was taught (recognizing) | judges a new claim against criteria (analyzing errors, level 3) |
| **fix / correct** | corrects an error using a learned procedure (executing) | critiques someone else's process and suggests an improvement (analyzing errors, level 3) |
| **choose / select** | selects the correct answer (recognizing) | chooses the best option based on criteria (decision making, level 4) |
| **solve** | solves a routine problem with a learned procedure (executing) | reaches a goal despite an obstacle or constraint (problem solving, level 4) |
| **evaluate** | — | judges a process or claim (analyzing errors, level 3), or importance for themselves (examining importance, level 6) |

**The default reading is always the lowest level the wording allows.** Assign a higher level only when the wording explicitly requires it: new or unfamiliar examples, choosing by criteria, justification, comparison, prediction, a personal attitude.

When writing an objective, word it so that it is clear what students do (taught vs. new, someone else's vs. their own, one correct answer vs. choosing by criteria).

---

## 7. Learning context

- Suggest **two variants** of the context for each objective (unless the teacher wants something else).
- A context is a **specific situation, material, or topic**: a Scratch game, a news report about leaked passwords, the student's own password, a video of a practice session.
- For recognizing and recalling, the context is the topic or material in which the knowledge was taught (a houseplant on the windowsill, the desktop computer in the computer lab).
- The variants should be **different**: school vs. everyday life, different tools, different subjects.
- The context must actually make the objective possible. At level 4 it must contain a choice, an obstacle, a hypothesis, or an open question. At levels 5 and 6 it is about the student's own work or situation.
- The context is **appropriate for the age** of the grade level. Unless the teacher explicitly asks, don't choose distressing topics: violence, death and tragedy, self-harm, sexuality, drugs, cyberbullying of real people.
- When a context uses AI or an online tool, assume a tool the school has approved for that age. Don't work with the likeness of real people.
- Levels 5 and 6 must not ask students to share private or sensitive information. Students can keep their reflection to themselves (a learning journal) and share it only if they want to.

---

## 8. Success criterion

For each objective, write **one short sentence, two at most**: how we will know that students have met the objective. Describe an observable performance, not a percentage threshold. The criterion must not assume failure: students can succeed on the first try.

| Levels | What the criterion assesses |
| :---- | :---- |
| 1–2 | correctness and accuracy of the result |
| 3–4 | also the quality of reasoning: students must show, justify, or explain it |
| 5–6 | the quality of self-reflection: specificity, evidence, judging their own reasoning. **It never assesses which emotion students feel or how motivated they are.** |

| Process | The criterion must check that students… |
| :---- | :---- |
| Recognizing | correctly confirm or reject the statements presented |
| Recalling | state the correct information that was taught |
| Executing | perform the procedure without significant errors |
| Integrating | express the core and separate essential from nonessential; for a procedure, the steps, their order, and its logic |
| Symbolizing | produce a representation that is accurate and captures the essential elements |
| Matching | compare based on essential features and describe similarities and differences accurately |
| Classifying | identify the features, place the item in a category, and justify it |
| Analyzing errors | name the error and explain why it is an error |
| Generalizing | state a rule that fits all the examples and note any exceptions |
| Specifying | use the right rule and deduce the consequence from it |
| Decision making | identify the options and criteria and choose the option that best meets them |
| Problem solving | name the obstacle, try a solution, adjust it if it doesn't work, and explain how the knowledge helped |
| Experimenting | base the prediction on a principle, run an experiment that actually tests it, and draw a conclusion that matches the result |
| Investigating | separate what is known from what is disputed and support the conclusion with arguments from sources |
| Specifying goals | set a goal that is specific and checkable, with a plan that has steps, a time frame, and resources |
| Process monitoring | describe while working what is working, what isn't, and what they will change |
| Monitoring clarity | name precisely what is unclear, or describe specifically which parts are clear and how they know |
| Monitoring accuracy | support their judgment with an outside source |
| Importance, efficacy, emotional response, motivation | name their attitude, explain what it rests on, and judge how reasonable their thinking is |

**Student version.** Success criteria can be written for students too, in age-appropriate language for self-assessment: "I can explain in my own words why a plant needs light."

---

## 9. Generating objectives

1. **Identify the domain and type of knowledge** (section 2.1). When a concept includes both information and a procedure, decide separately for each objective.
2. **For each level, choose one process** that fits the concept most naturally:
   - **Level 1:** executing for procedures, recalling for information (recognizing for simple facts).
   - **Level 2:** integrating. Symbolizing where the knowledge has a natural visual form (a procedure, a sequence, a structure, a relationship between variables).
   - **Level 3:** concepts → matching or classifying; claims and principles → analyzing errors or specifying; procedures → analyzing errors or matching; data and examples → generalizing.
   - **Level 4:** a choice between options → decision making; an obstacle → problem solving; a testable hypothesis → experimenting; a "why / what if" question answered from sources → investigating.
   - **Level 5:** for procedures, specifying goals or process monitoring; for information, monitoring clarity or accuracy.
   - **Level 6:** any of the four processes. When writing objectives for several concepts, vary them.
3. **Check the constraints** in section 5.
4. **Write the objective** using the frame and style rules (section 3).
5. **Add two learning contexts** and a **success criterion**.
6. **Run the checklist** (section 11) and fix anything that doesn't fit.
7. When writing objectives for several concepts, keep them **varied**. But the process that fits the concept best always comes first. Vary only among processes that fit equally well.

---

## 10. Output formats

### For reading (default for a set of objectives)

```
### Debugging a program
Main domain: mental procedures (process) · Subject: computer science · Grade: 6–7

| Level | Process | Domain | Objective | Learning context | Success criterion |
|---|---|---|---|---|---|
| 1 | executing | mental procedures | Students will fix an error in a short program. | a Scratch program with two blocks swapped · a Python script with an error in a condition | After the fix, the program works as specified and the fix introduced no new error. |
```

Always include the **Domain** column, even when it is the same for every objective. Include the subject and grade if the teacher gave them.

### For reviewing existing objectives

This format is for objectives that should follow our style. Analyze standards and objectives written by others with section 13.

```
**Original objective:** Students will be able to understand how the internet works.
**Level / process / domain:** 2 Comprehension / integrating / information (estimate of intent)
**What doesn't fit:** checklist item 1 ("be able to," unobservable "understand"), item 10 (no success criterion can be written)
**Revised:** Students will explain how data travels across the internet.
```

- When the verb doesn't define a process ("understand," "realize"), estimate the intent and say that it is an estimate.
- When an objective is ambiguous, give both readings and suggest a revision for each.
- When an objective combines several processes or domains, split it into several objectives.
- When an objective passes the checklist, write "no changes needed" and add a suggestion only if useful.
- Add contexts and success criteria only when asked.

---

## 11. Checklist

Every objective must pass every item. If it doesn't, rewrite it.

1. Does it start with "Students will" and an observable verb? No "be able to," "can," "know," "understand"?
2. Does it have one main verb (two at most, if they form one performance)?
3. Is it short (about 15 words) and free of filler? Is "their own" used only at level 5 or 6?
4. Is the knowledge named, without a scenario? Is the scenario in the context, with only the essential condition left in the objective?
5. Does the verb match the process the objective is assigned to (section 6)?
6. Does the process fit the domain (section 5)? No executing for information, no specifying for details?
7. At level 4: is the knowledge essential to the task, and is it clear what type of task it is (choice, obstacle, hypothesis, question)?
8. At levels 5 and 6: is the objective about the student's own knowledge or skill?
9. Is it free of the standard's ID code? Does it reflect the content of the standard through its verbs and concepts?
10. Is it observable, and can a success criterion be written for it?
11. Is it appropriate for the grade level (in the complexity of the knowledge and context, not the level)?

---

## 12. Model examples

### 12.1 The New Taxonomy grid (computer science)

| Level | Information: encryption | Mental procedures: debugging a program | Psychomotor procedures: touch typing |
| :---- | :---- | :---- | :---- |
| **1** | Students will state the purpose of an encryption key. *(recalling)* | Students will fix an error in a short program. *(executing)* | Students will touch-type a text without significant errors. *(executing)* |
| **2** | Students will explain the roles of the algorithm and the key in encryption. *(integrating)* | Students will draw a flowchart of the debugging process. *(symbolizing)* | Students will explain the principle of touch typing and describe its advantages. *(integrating)* |
| **3** | Students will evaluate the accuracy of the claim "this password is secure" using a specific example. *(analyzing errors)* | Students will critique a classmate's debugging process and suggest an improvement. *(analyzing errors)* | Students will identify errors in touch-typing technique in a video recording. *(analyzing errors)* |
| **4** | Students will choose appropriate security for sharing data based on criteria set in advance. *(decision making)* | Students will use systematic debugging to fix a broken game. *(problem solving)* | Students will test experimentally which way of practicing touch typing works best for them. *(experimenting)* |
| **5** | Students will verify the accuracy of their own claims about encryption against a credible source. *(monitoring accuracy)* | Students will set a goal and plan for improving their debugging of a specific program. *(specifying goals)* | Students will monitor progress toward their goal during touch-typing practice. *(process monitoring)* |
| **6** | Students will evaluate the importance of knowing about encryption for their own needs. *(examining importance)* | Students will evaluate their ability to improve at debugging programs. *(examining efficacy)* | Students will determine how important touch typing is for their own needs. *(examining importance)* |

### 12.2 A complete set for one concept

**Debugging a program** · Main domain: mental procedures (process) · Subject: computer science · Grade: 6–7

| Level | Process | Domain | Objective | Learning context | Success criterion |
| :---- | :---- | :---- | :---- | :---- | :---- |
| 1 | executing | mental procedures | Students will fix an error in a short program. | a Scratch program with two blocks swapped · a Python script with an error in a condition | After the fix, the program works as specified and the fix introduced no new error. |
| 2 | symbolizing | mental procedures | Students will draw a flowchart of the debugging process. | debugging a Scratch game · debugging a calculator in Python | The flowchart shows the essential steps (reproduce the error, guess the cause, change one thing, test) in the right order. |
| 3 | analyzing errors | mental procedures | Students will critique a classmate's debugging process and suggest an improvement. | a classmate's log showing several changes at once · a classmate who fixes code without running it again | Students name the error in the process, explain why it makes the cause hard to find, and suggest a better step. |
| 4 | problem solving | mental procedures | Students will use systematic debugging to fix a broken game. | a Scratch game that sometimes crashes · a web game where a button doesn't respond | The game works, and students describe how the debugging process led them to the cause. |
| 5 | specifying goals | mental procedures | Students will set a goal and plan for improving their debugging of a specific program. | their own game project · a Python homework assignment | The goal is specific and checkable; the plan has steps, a time frame, and resources. |
| 6 | examining efficacy | mental procedures | Students will evaluate their ability to improve at debugging programs. | after finishing a project · at the start of a programming unit | Students state how much they believe they have the ability and resources to improve, explain why, and judge whether their reasoning is sound. |

### 12.3 Beyond computer science: the median (based on an example in the book)

The book shows that the domains can alternate within one topic. The median is information (what it is); calculating it is a mental procedure.

| Level | Process | Domain | Objective |
| :---- | :---- | :---- | :---- |
| 1 | recognizing | information | Students will recognize correct statements about the median. |
| 1 | executing | mental procedures | Students will calculate the median of a data set. |
| 2 | integrating | information | Students will describe the defining characteristics of the median. |
| 3 | matching | information | Students will compare the median, the mean, and the mode. |
| 4 | problem solving | mental procedures | Students will solve a problem that requires calculating and interpreting the median. |

### 12.4 Across subjects

| Subject, grade | Level / process / domain | Objective | Learning contexts |
| :---- | :---- | :---- | :---- |
| ELA, grade 4 | 2 / integrating / information | Students will summarize the main idea of a text and the details that support it. | a news article about a local park · an informational text on space exploration |
| ELA, grade 7 | 3 / matching / information | Students will compare two arguments on a debatable issue based on the quality of their evidence. | Should cell phones be allowed in classrooms? · Should students have a four-day school week? |
| Math, grade 6 | 1 / executing / mental procedures | Students will calculate the area of a composite figure. | the floor plan of a classroom · a garden bed made of rectangles and triangles |
| Science, grade 5 | 4 / experimenting / information | Students will test experimentally whether mixing two substances produces a new substance. | baking soda and vinegar · salt and water |
| Social studies, grade 8 | 4 / investigating / information | Students will use sources to investigate the causes of a historical event. | the Dust Bowl · the Boston Tea Party |
| PE, grade 3 | 1 / executing / psychomotor procedures | Students will throw overhand without significant errors in technique. | throwing a beanbag at a target · throwing a ball to a partner |

---

## 13. Analyzing existing wording (standards and others' objectives)

Analysis is a different task from writing. You don't correct the wording; you find out where in the grid it points.

### 13.1 Principles

- **Don't judge the style.** Standards are quoted word for word and have their own style.
- **The performance sets the level, not the verb** (section 6).
- **The default reading is the lowest level the wording allows.** Assign a higher level only when the wording explicitly requires it. Don't assume a more demanding task than the text implies.
- **The grade level doesn't set the level, but it helps with interpretation.** When the wording allows several readings, choose the one that matches typical instruction at that grade.
- **Decide.** Give one main classification for each performance. Give an alternative only when it is reasonable, and say what would trigger it.
- **Never invent a standard or its wording.** Work only with the text the teacher provides.

### 13.2 Steps

1. **Break the wording into performances.** A performance is a verb whose subject is the student. Standards often join several performances with commas or "and."
2. **Verbs in relative clauses and modifiers are not performances.** They describe the knowledge. In "data that can help them make better decisions," students don't make decisions; they give examples of a kind of data.
3. **Don't classify a supporting verb of the same performance separately.** In "draw conclusions and explain how they reached them," the explanation is part of generalizing: students defend their conclusion.
4. For each performance, identify the **domain**: what knowledge students work with (section 2.1).
5. Identify the **level and process** with the table in 13.3. Start from the lowest row that matches the wording.
6. Write the result in the format in 13.4.

### 13.3 Level signals

| What the wording asks students to do | Level / process |
| :---- | :---- |
| select or confirm a correct statement from options | 1 recognizing |
| state, list, or describe what was taught or what they know from everyday life | 1 recalling |
| perform a learned procedure, including reading information from a given table, graph, or map, or solving a routine problem | 1 executing |
| express the core in their own words, explain how or why something works, describe the logic of steps | 2 integrating |
| represent (diagram, graph, model) | 2 symbolizing |
| compare, classify, find an error, judge a new claim, detect manipulation, infer a conclusion or rule, predict a consequence | 3 analysis (process per section 4) |
| choose by criteria, solve a problem with an obstacle, test a hypothesis, investigate a question using sources | 4 knowledge utilization |
| set a goal, monitor their own process, name their own points of confusion, verify their own claims | 5 metacognition |
| examine their own attitude: importance, belief in improving, emotions, motivation | 6 self-system |

**Recalling vs. executing:** an answer from memory is recalling. An answer students get from given material using a learned procedure (reading a table, for example) is executing. Both are level 1.

### 13.4 Output format

```
**Wording:** …
**Grade:** …

| Performance (quote) | Domain | Level | Process | Rationale |
|---|---|---|---|---|
| … | … | … | … | one sentence |

**Verbs that are not performances:** "…" and why
**Alternative reading:** only if reasonable, and what would trigger it
**Suggested objectives:** only on request, following sections 3 and 9
```

### 13.5 Calibration examples

**Wording:** Determine the main idea of a text and explain how it is supported by key details; summarize the text. **Grade:** 4 (reading)

| Performance (quote) | Domain | Level | Process | Rationale |
| :---- | :---- | :---- | :---- | :---- |
| determine the main idea of a text and explain how it is supported by key details | information | 2 | integrating | Students separate the essential from the nonessential in a text. The explanation is part of the same performance. |
| summarize the text | information | 2 | integrating | Students express the core of the text in their own words. |

**Alternative reading:** If students had to judge whether the details really support the main idea, it would be level 3, analyzing errors.

**Wording:** Draw a scaled picture graph and a scaled bar graph to represent a data set with several categories. Solve one- and two-step "how many more" and "how many less" problems using information presented in scaled bar graphs. **Grade:** 3 (math)

| Performance (quote) | Domain | Level | Process | Rationale |
| :---- | :---- | :---- | :---- | :---- |
| draw a scaled picture graph and a scaled bar graph to represent a data set | mental procedures | 1 | executing | Building a graph from data is a learned procedure. |
| solve one- and two-step "how many more" and "how many less" problems | mental procedures | 1 | executing | Routine problems solved with a learned procedure. "Solve" does not mean level 4 here: there is no obstacle or constraint. |

**Wording:** Conduct an investigation to determine whether the mixing of two or more substances results in new substances. **Grade:** 5 (science)

| Performance (quote) | Domain | Level | Process | Rationale |
| :---- | :---- | :---- | :---- | :---- |
| conduct an investigation to determine whether the mixing of two or more substances results in new substances | information | 4 | experimenting | Students test a hypothesis about matter by observation. The knowledge (what counts as a new substance) is the basis of the experiment. |

**Wording:** Recognize when irrelevant evidence is introduced. **Grade:** 8 (reading, part of a longer standard)

| Performance (quote) | Domain | Level | Process | Rationale |
| :---- | :---- | :---- | :---- | :---- |
| recognize when irrelevant evidence is introduced | information | 3 | analyzing errors | Students judge new arguments. "Recognize" does not mean selecting a statement that was taught. |

**Alternative reading:** If students only marked types of irrelevant evidence that were taught, on a quiz, it would be level 1, recognizing.

---

## 14. The New Taxonomy and other frameworks

- **Cognitive, affective, psychomotor.** The New Taxonomy covers what this older split aimed at. Psychomotor procedures are a knowledge domain of their own. Attitudes, beliefs, emotions, and motivation are addressed at level 6 (self-system), and students' management of their own learning at level 5 (metacognition). Don't pack several domains into one sentence. Write a separate objective for each.
- **Core competencies and transferable skills.** A competency is not added to the objective as an extra verb. Note under the objective which competency it develops and how that will show.
- **Understanding by Design.** For a unit, a set of objectives can serve one big idea or essential question. Each objective still targets one process.
- **Proficiency scales.** Marzano's 4-point proficiency scales are a different tool from this taxonomy. A proficiency scale describes levels of performance on one objective; the taxonomy describes the type of thinking an objective requires.
