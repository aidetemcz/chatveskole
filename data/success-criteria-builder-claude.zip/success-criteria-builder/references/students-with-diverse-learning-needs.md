# Adapting Assessment Criteria for Students with Diverse Learning Needs

This document supports teachers in adapting assessment criteria for
students who benefit from individualized supports. In U.S. K–12
schools, these students are identified through several pathways,
each with its own legal framework, documentation, and instructional
implications:

- IEP (Individualized Education Program) under IDEA
- 504 plan under Section 504 of the Rehabilitation Act
- English Learner (EL) / Multilingual Learner (MLL) status
- Gifted and twice-exceptional (2e) identification
- Students experiencing adverse circumstances (poverty, foster
  care, housing instability)

When adapting criteria, follow these principles:
- Maintain the cognitive demand of the criterion. Adaptations change
  *how* a student demonstrates learning, not *what* they learn.
- Use the supports specified in the student's IEP, 504 plan, or
  language-development plan.
- Use person-first or identity-first language consistent with the
  student's preference and your school's guidance.
- Coordinate with special education teachers, EL specialists,
  speech-language pathologists, school psychologists, and gifted
  coordinators as appropriate.

----------------

## Students with IEPs (Individualized Education Programs)

Students with an IEP have been identified under one of the 13
disability categories defined by the Individuals with Disabilities
Education Act (IDEA). The IEP specifies goals, services,
accommodations, and modifications. Always read the student's IEP
before adapting criteria.

### Specific Learning Disability (SLD)

The largest IDEA category. Includes dyslexia, dysgraphia,
dyscalculia, and other disorders affecting one or more academic
processes. Common examples:

- **Dyslexia** — affects decoding, reading fluency, and reading
  comprehension.
- **Dysgraphia** — affects handwriting, spelling, and written
  expression.
- **Dyscalculia** — affects number sense, calculation, and
  mathematical reasoning.

Adaptation strategies for assessment criteria:
- Allow alternate response formats (oral instead of written,
  typed instead of handwritten, voice-to-text).
- Reduce reading load on the criterion itself; use simpler
  syntax and high-frequency vocabulary.
- For dyscalculia, allow calculators or formula references when
  the math is not the construct being assessed.
- Break complex criteria into smaller, sequential steps.

### Speech or Language Impairment (SLI)

Includes receptive language disorders, expressive language
disorders, articulation disorders, fluency disorders (stuttering),
and voice disorders. May include conditions sometimes labeled
aphasia, dysphasia, dysarthria, or apraxia of speech.

Adaptation strategies:
- For receptive/expressive language difficulties, allow visual
  responses (drawings, diagrams, demonstrations).
- For articulation or fluency difficulties, do not require oral
  performance for assessment unless oral language is the construct
  being assessed.
- Coordinate with the speech-language pathologist (SLP).

### Other Health Impairment (OHI)

The category that includes ADHD, chronic illness, and other
conditions limiting strength, vitality, or alertness. ADHD is the
most common.

Adaptation strategies for ADHD:
- Break long criteria into shorter steps with explicit checkpoints.
- Use clear, single-step directions with visual or written
  reminders.
- Allow movement breaks during longer assessment activities.
- Reduce extraneous information in the criterion text.

### Autism Spectrum Disorder (ASD)

Includes the full range of presentations previously labeled as
autism, Asperger's syndrome, or PDD-NOS. (DSM-5, 2013, consolidated
these under ASD.)

Adaptation strategies:
- Make implicit expectations explicit. State criteria literally and
  concretely.
- Provide visual supports — examples, models, rubrics, exemplar
  responses.
- Allow alternate ways to demonstrate social/communication
  competencies (written, drawn, role-played in a comfortable
  setting).
- Avoid figurative language, idioms, or metaphors in criterion
  wording.

### Emotional Disturbance (ED)

A category for students whose emotional or behavioral functioning
significantly affects educational performance.

Adaptation strategies:
- Frame criteria positively (what the student will do, not what
  they should avoid).
- Build in self-regulation supports — clear expectations, frequent
  feedback, opportunities to demonstrate learning in low-stakes
  formats.
- Coordinate with school counseling and behavioral support staff.

### Intellectual Disability

A category for students with significantly below-average general
intellectual functioning and adaptive behavior.

Adaptation strategies:
- Modify the criterion's cognitive demand if specified by the IEP.
- Use concrete, hands-on tasks; reduce abstract language.
- Allow extended time, simplified vocabulary, picture supports,
  and step-by-step prompts.

### Other IDEA Categories

The remaining IDEA categories include: Hearing Impairment (HI),
Visual Impairment including Blindness (VI), Deaf-Blindness,
Orthopedic Impairment, Traumatic Brain Injury (TBI), Multiple
Disabilities, and Developmental Delay (early grades only).

For each of these, adaptation depends on the specific functional
implications:
- For HI/VI students: provide accessible formats (Braille, large
  print, captions, ASL interpretation, audio descriptions).
- For students with motor or orthopedic disabilities: provide
  assistive technology, alternate response formats, and adapted
  materials.
- For students with TBI: support working memory, processing speed,
  and attention with structured supports and chunking.

----------------

## Students with 504 Plans

Section 504 of the Rehabilitation Act covers students with a
documented condition that substantially limits a major life
activity but who do not require specialized instruction (and
therefore don't qualify for an IEP). Common 504 supports include
extended time, preferential seating, breaks, and quiet testing
environments. Conditions often supported under 504 include ADHD
(when not affecting academic performance significantly), anxiety,
diabetes, food allergies, and chronic medical conditions.

Adaptation strategies:
- Apply accommodations specified in the 504 plan to assessment
  contexts.
- Do not modify the cognitive demand of the criterion — 504
  provides accommodations, not modifications.

----------------

## English Learners (EL) / Multilingual Learners (MLL)

Students whose home language is not English and who are still
developing English proficiency. These students are typically
identified through home-language surveys and English-proficiency
assessments (e.g., WIDA ACCESS, ELPAC). Their progress is
tracked across listening, speaking, reading, and writing.

Adaptation strategies:
- Use plain, high-frequency vocabulary in the criterion itself.
- Provide visual supports — images, diagrams, sentence frames,
  word banks.
- Allow students to demonstrate content knowledge using the language
  of their choice when language is not the construct being assessed.
- Differentiate criteria across WIDA proficiency levels (Entering,
  Emerging, Developing, Expanding, Bridging, Reaching).
- Honor students' home languages as instructional assets.

EL students are not students with disabilities. EL services are
covered under separate federal frameworks (Title III, ESSA,
Castaneda v. Pickard).

----------------

## Gifted and Twice-Exceptional (2e) Students

Gifted students demonstrate exceptional ability in one or more
areas — academic, creative, leadership, or artistic. Identification
and services are determined at the state and district level (no
federal mandate). Twice-exceptional (2e) students are gifted
students who *also* have an identified disability (most commonly
SLD, ADHD, or ASD).

Adaptation strategies:
- For gifted students: deepen, don't accelerate. Adapt criteria to
  invite higher-order thinking — analysis, evaluation, creation —
  and authentic application.
- Allow choice in how the student demonstrates mastery (research
  product, design challenge, original creation).
- For 2e students: address both the giftedness and the disability.
  Don't allow strengths to mask needs, and don't allow needs to
  obscure strengths.
- Watch for asynchronous development — strong cognitive abilities
  paired with age-typical or below-typical executive function or
  social-emotional skills.

----------------

## Students Experiencing Adverse Circumstances

Students experiencing poverty, housing instability, foster care,
or recent immigration may face barriers to learning that are not
disabilities but still warrant thoughtful adaptation. The
McKinney-Vento Act protects students experiencing homelessness
and ensures their right to school stability and support.

Adaptation strategies:
- Do not penalize students for resource gaps (lack of internet,
  quiet study space, materials at home). Provide what's needed at
  school.
- Be flexible with deadlines and out-of-school work expectations.
- Build relationships before raising the bar. Trauma-informed
  practices support learning.
- Connect families with school counselors, social workers, and
  community resources.
- Recognize that these students are not students with disabilities
  and should not be referred to special education on the basis of
  circumstance alone.

----------------

## Coordination Across Roles

Adapting criteria is a team effort. Coordinate as appropriate with:
- Special education teachers and case managers (for IEP students)
- 504 coordinators (for students on 504 plans)
- EL/ESL specialists and bilingual staff (for EL/MLL students)
- Gifted coordinators (for gifted and 2e students)
- School counselors, social workers, and psychologists
- Speech-language pathologists, occupational therapists, and
  physical therapists (as relevant to the student's plan)
- Families — they are partners in the adaptation process.

Always work within the student's documented plan and respect
confidentiality requirements (FERPA, IDEA confidentiality
provisions).