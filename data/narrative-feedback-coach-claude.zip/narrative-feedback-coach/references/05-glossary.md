# Glossary of Key Terms

This glossary explains terms used throughout this assessment methodology and the related AI assistants. Definitions are calibrated for U.S. K–5 elementary classroom teachers and align with widely used U.S. assessment frameworks.

## A

### asset-based language

Language that names what a student does and can do, framed in terms of growth and possibility rather than deficit. The opposite of deficit framing ("you can't," "you don't manage to," "you're behind").

### assessment

The full range of activities through which teachers and students gather information about learning. Assessment is broader than grading — it includes observation, conversation, student work, self-assessment, and reflection.

## C

### core competencies (transferable skills)

The integrated knowledge, skills, dispositions, and habits of mind that prepare students for academic success, civic participation, career readiness, and lifelong learning. They are not content-area-specific; they cut across disciplines and develop over the course of a student's K–12 experience. Aligned with CASEL, the 4Cs (Partnership for 21st Century Learning), ISTE Standards, and Portrait-of-a-Graduate frameworks.

### criterion-based assessment

Assessment that judges student performance against predefined criteria rather than against other students. The opposite of norm-referenced assessment.

## D

### descriptive language

Non-evaluative language that describes a situation, behavior, or result without using judgment-loaded adjectives ("smart," "quick," "difficult"). Descriptive language names what is observed.

## E

### evaluative judgment

A verbal expression of evaluation, classification, or labeling applied to a person, their behavior, or a result they produced. The opposite of descriptive language.

### evidence of learning

Concrete, observable information that demonstrates a student has learned something — work products, performances, conversations, self-assessments, observations. Evidence is what makes assessment trustworthy.

## F

### formative assessment

An approach to assessment that treats learning as an ongoing process. Its purpose is to help students understand where they are, what they do well, what they still need to develop, and how to move forward. It also helps teachers adapt instruction to students' actual needs.

## H

### habits of work

A category of skills and dispositions sometimes assessed separately from academic content — including persistence, collaboration, organization, and engagement. Often appears as a distinct section on the report card.

### holistic approach

A whole-child approach to the student, where the goal is to support development not only cognitively but also socially, emotionally, and in terms of wellbeing and quality of life. Learning is seen as integrated and connected, even when teachers plan or assess specific aspects of it.

## I

### indicator

A specific, observable behavior or outcome that signals a criterion has been met. Indicators make abstract criteria concrete and observable.

### individualized assessment

Assessment that does not compare students to one another. A student's performance is judged against their own prior performance, their individuality, and their specific abilities. Assessment reflects current mastery, growth relative to the goal, and possibilities for further development.

### intrinsic motivation

A student's motivation that comes from within — interest in the work itself, the satisfaction of mastery, the desire to learn. Excessive teacher-centered praise ("I'm so pleased") can undermine intrinsic motivation by shifting the student's focus to pleasing the teacher.

## L

### learning objective

A specific, measurable, observable statement of what students will know or be able to do by the end of a lesson, unit, or period. In the SWBAT format: "Students will be able to…"

### letter grades

Traditional U.S. grading using A–F scale. Distinct from proficiency-based or standards-based grading.

## M

### MAPS scale

A 4-point self-assessment scale used by students to reflect on their own progress: M = Mastered, A = Almost mastered, P = Partially mastered, S = Still learning. Adapted from a Czech formative assessment framework, aligned with U.S. standards-based grading practices and Marzano-style 4-point proficiency scales.

## N

### narrative feedback

Written comments on a student's learning, in the form of descriptive prose rather than letter grades or numerical scores. Can be used for ongoing formative feedback, end-of-term report card narratives, or both.

## P

### peer assessment

Assessment in which students give one another feedback on their work, using shared criteria. Builds students' assessment capacity and supports learning for both the giver and receiver.

### proficiency scale

A scale (often 1–4) used in standards-based grading to describe levels of mastery: typically 4 = Advanced, 3 = Proficient, 2 = Developing, 1 = Beginning. Marzano's work is widely cited as a reference.

## R

### report card narrative

The written commentary on a student's progress that appears on a report card or progress report — addressed either to the student (in second person) or to the family (in third person), depending on school practice.

## S

### self-assessment

Assessment in which students reflect on their own learning, often using shared criteria or a scale (such as MAPS). Self-assessment builds metacognition and learner agency.

### standards-based grading

A grading approach in which student progress is reported relative to specific learning standards, typically using a proficiency scale rather than letter grades. Common in K–5 elementary schools.

### SLD (Specific Learning Disability)

An IDEA category for students whose learning is significantly affected by one or more disorders in psychological processes. Includes dyslexia, dysgraphia, and dyscalculia.

### SWBAT

"Students will be able to…" — the most common U.S. format for writing learning objectives. Each objective begins with this phrase, followed by an observable, measurable verb.

### success criteria

Specific, observable indicators that show whether a learning objective has been met. Success criteria can be written in two versions: a teacher version (using professional terminology) and a student version (in age-appropriate language for self-assessment).

### summative assessment

Assessment conducted at the end of a defined period (term, year, end of unit). The focus is on the level of learning the student has reached. Distinct from formative assessment, which happens during the learning process.

## T

### transferable skills

See core competencies. The terms are used interchangeably in this methodology.

## W

### whole-child education

An educational approach focused on supporting the full development of the student — cognitive, social, emotional, and physical — rather than only academic content. Aligns with ASCD's Whole Child framework and CASEL's SEL competencies.
