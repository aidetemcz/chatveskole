# Narrative Feedback on Student Behavior and Habits of Work

Narrative feedback on a student's behavior and habits of work is a distinct part of the report card. Its purpose is to give a whole-picture view of the student in school — not just compliance with rules, but development of the transferable skills and dispositions that prepare students for life and learning.

It's not possible to address every transferable skill in a single report card narrative. That doesn't mean teachers stop developing and observing those skills throughout the year. For the purposes of the report card, the relevant skills group naturally into three categories:

- Self-development — the student's growth in relation to themselves.
- Engagement with others — the student's growth in relation to classmates, the school community, and the wider world.
- Approach to learning and work — how the student engages with academic tasks and effort.

## Foundations of narrative feedback on behavior

The foundation for assessing behavior is twofold:

- The school's broader educational goals — building transferable skills and a strong general foundation, oriented toward real-world situations and practical action.
- The school's code of conduct or behavior expectations.

It's important to understand that this section is not the only place where transferable skills are observed and reported on. Building these skills is the work of the entire school experience: all instructional content, all activities, all interactions in school contribute to their development. Content is the vehicle; the transferable skills are the destination.

Narrative feedback on transferable skills therefore appears throughout the report card — in subject areas as well as here. This particular section focuses on the **observable behaviors** through which students demonstrate the skills and dispositions they've developed. These behaviors can be defined, anchored to clear criteria, and assessed based on systematic observation and documentation of the student's actions and work.

This approach reflects current thinking on lifelong learning: transferable skills are what every learner needs for personal fulfillment, growth, employability, social participation, sustainable living, and engaged citizenship.

## Common pitfalls to watch for

- This is a substantial expansion compared with assessing behavior through a single letter or rating. It's important that all teachers are familiar with the criteria and indicators in advance and use them consistently throughout the term.
- Increased time demands. With large numbers of students (especially at the middle school level), teachers in individual subjects may not have time to comment on each student. Teachers who see students less frequently — for example, in subjects with fewer hours per week — may find it harder to recall specific evidence and assess all relevant skills fairly. Communication and collaboration among teachers is essential.
- Differing perspectives. Teachers may form different impressions of the same student depending on the student's relationship to their subject and the attitude they bring to it. The classroom teacher (or homeroom advisor) may find it challenging to weave feedback from multiple colleagues into a coherent picture that truly reflects the student's behavior.
- For this kind of feedback to be meaningful, it must be grounded in ongoing observation throughout the term, anchored in clear criteria and supported by indicators. Schools should hold ongoing conversations about what the criteria mean, what indicators look like in practice, what strategies support growth, and how to gather evidence. This is a long-term professional development process.
- Time pressure can lead to formulaic narratives. When teachers are stretched thin by other demands, they may resort to template-style comments. Schools need to create the conditions — protected time and structural support — for this work.

## What strong narrative feedback offers

- It gives a substantially richer picture of the student's behavior than a single letter or summary rating.
- It situates the student's growth in context, supporting a whole-child approach to assessment.
- It makes the development of life-essential skills visible — the skills that matter for lifelong learning.
- It captures the student's growth in these areas relative to their previous performance.
- It helps the student see the connection between how they approach learning and how they engage in school more broadly.
- It supports the student in understanding their own learning, their progress, and their role in taking ownership of it. In this way, it fulfills the core functions of formative assessment.
