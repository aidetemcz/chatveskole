# Narrative Feedback in Core Academic Subjects

This file applies to narrative feedback in core academic subjects: English Language Arts, mathematics, science, social studies, and related disciplines.

The purpose of assessment in these subjects is not only to evaluate the student's level of mastery of grade-level standards and core competencies, but more importantly to highlight the student's strengths and identify possibilities for continued growth. The narrative on the report card connects summative reporting with formative feedback, drawing on the teacher's ongoing work with the student over the term.

The narrative supports a combined approach: the report card may include a letter or proficiency grade, a narrative comment, or both, depending on the school's reporting structure.

## Common pitfalls to watch for

- Reluctance to move beyond grades. Some teachers may be hesitant to step away from a single letter or proficiency grade. The narrative does not have to replace the grade — it complements it with substantive description of the student's learning.
- Increased time demands. Strong narrative feedback depends on ongoing communication and collaboration among teachers and on steady documentation of the student's learning process. This is especially important when assessing integrated or interdisciplinary subjects.
- Differing perspectives in integrated or team-taught subjects. When several teachers contribute to one subject area, their views may differ depending on which aspect of the subject the student favors and where they show stronger results. When a scaled rating is required, teachers will need to reach consensus. Differences can be acknowledged in the narrative comment itself.
- For narrative feedback on individual focus areas to be meaningful, it must be grounded in ongoing documentation of results in those areas — based on success criteria and indicators. Teachers need to track student progress systematically, use descriptive and analytical language, and share the success criteria with students (and families) during the learning, in clear and concrete language.
- Time pressure can lead to formulaic comments. When teachers don't have enough time for individualized narrative feedback, they may resort to template-style comments. Schools need to create the conditions for this work — protect teacher time, provide professional learning, and build the know-how to make narrative feedback a sustainable part of practice.

## What strong narrative feedback offers

Narrative feedback grounded in ongoing documentation gives families and students a more accurate, comprehensive picture of the student's learning. It captures growth in specific areas relative to the student's own starting point. Recognizing improvement, effort, and progress — along with concrete suggestions for next steps — increases student motivation and engagement.

Documenting the learning process over time depends on collaboration among teachers. This is especially important when looking for connections across content areas, supporting interdisciplinary learning, and integrating knowledge with skills as students apply facts, build concepts from inquiry, and transfer learning across contexts.
