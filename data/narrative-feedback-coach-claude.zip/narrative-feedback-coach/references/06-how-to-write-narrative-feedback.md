# How to Write Narrative Feedback on a Report Card

Author: Jana Kratochvílová

U.S. adaptation: Eva Nečasová (AI dětem)

How do you write narrative feedback? Plenty of advice is out there
— in professional publications, online communities, webinars,
teacher Facebook groups. So this piece just adds another voice to
that pond of wise counsel — but maybe brings something new. Let's
think about narrative feedback on a report card more comprehensively.
The most essential part is, of course, content — but before writing,
it helps to discuss across the teaching staff its form, structure,
the conditions for writing it, and the practical work around
storage, printing, and delivery.

## Content

Content is the area teachers spend the most time thinking about.
The wording of evaluative statements can deeply shape how messages
are received by students and their families, what next steps the
student takes, and how their attitude toward learning develops.
Content doesn't crystallize overnight. It builds up through the
student's long-term work, the teacher's ongoing observation and
formative feedback, and the student's own self-assessment and peer
feedback.

Narrative feedback should inform students and their families,
prompt continued learning, and motivate growth. Let's look at what
that means in practice.

### Three core functions of narrative feedback

**1. The informational function.**

Narrative feedback should describe the student's current level of
learning — particularly in relation to expected outcomes for each
subject, the student's own abilities, and their developmental
stage. It captures the student's results in motion: their strengths,
their growing edges, and their progress over time. The focus isn't
just on what content was covered, but on how well the student met
the expected outcomes.

**2. The process function.**

Narrative feedback should describe the student's approach to
learning — engagement, effort, persistence, collaboration,
self-direction, communication. This is essentially feedback on
core competencies and transferable skills: how the student
chooses learning strategies, plans and manages their own work,
shows curiosity and stamina, communicates with peers and adults,
and handles challenges.

**3. The motivation and forward-direction function.**

Narrative feedback should also point toward continued growth —
offering recommendations, strategies, and supports that can help
the student keep moving forward. Unfortunately, this part is often
missing from report card narratives.

### Examples: feedback on level of learning

- You write all numbers up to 100 correctly.
- You compare two-digit numbers accurately.
- You apply multiplication facts in real-world situations.
- You complete data tables without difficulty.
- You aren't yet sure how to apply spelling patterns for words
  with silent letters.
- You read for understanding well; comprehension comes
  consistently.
- You aren't yet able to / not yet able to…
- With light support, you find and sort information.
- You're starting to find your way in…
- A challenge for you right now is…
- You don't always apply your knowledge in new situations.
- You consistently use the rules for capitalization.
- You still need practice with applying punctuation rules in
  longer sentences.
- In math, you've worked on numbers up to 100 — writing them,
  matching them, comparing them, and adding and subtracting
  within 100. You handle this independently with only minor
  errors.

### Examples: feedback on the student's progress over time

- Your handwriting has shown clear improvement.
- We talked during the term about the layout and legibility of
  your notebook entries. Both have improved.
- In math, you made significant progress this term.

### Examples: feedback on the student's approach to learning

- You attended class regularly and engaged actively in discussions
  and group work.
- You haven't submitted any assignments through Google Classroom
  this term.
- You sometimes rush to finish your work quickly.
- You've adopted the routines for online communication in our
  class platform.

### Examples: recommendations for continued growth

- I recommend focusing on cursive or lowercase printing and on
  forming each letter consistently.
- Try paying closer attention to articles when you write —
  especially the indefinite article "a."
- I recommend practicing your handwriting daily, even when it
  feels challenging. With more practice, your hand will form
  letters more automatically and writing will become easier.
- Try rehearsing your presentation aloud at home — perhaps to a
  family member — so you feel more confident.
- When you aren't sure, use the reference chart for support; over
  time you won't need it.
- It helps you to study together with a classmate.
- Work on slowing down your reading pace.
- When you apply this skill, focus on…
- You learned to read fluently. While you read, you can use your
  finger to track where you are. It will help you stay focused on
  the line and the word you're reading.

### Putting it all together

A well-rounded narrative addresses all four dimensions, with
sensitivity to what the student needs:

1. The level of the student's outcomes
2. The student's progress over time
3. The student's approach to learning
4. Recommendations for continued growth

### Sample narrative

> Your writing continues to develop. You write more fluidly, and
> you more often use the correct slant and consistent letter size.
> Keep paying attention to careful handwriting, including when no
> adult is working with you. You now spell most words correctly,
> including those with silent letters and most homophones. With
> words where the spelling doesn't match the sound, you still need
> more time to write them confidently. When you aren't sure about
> a word, look for related forms that can help you. You've fully
> mastered word relationships (synonyms, antonyms, categories)
> and alphabetical order. You read fluently. With more complex
> comprehension questions — those that require attention to detail
> and connecting information across the text — you're still
> finding it harder to formulate answers. It might help to read
> the text in shorter sections and try retelling each one to
> someone. You've improved at following written directions;
> continue checking whether you've completed every step. You copy
> longer texts accurately.
>
> You add and subtract within 100, including problems that cross
> the tens, accurately and quickly. You multiply and divide
> confidently with facts for 2, 3, 4, 5, and 10. You solve simple
> word problems correctly, and when you read carefully, even
> word problems that include extra information. In geometry, you
> usually follow the correct procedures and have learned to hold
> your pencil with a lighter touch when measuring or drawing. Read
> the prompt more carefully — notice whether the measurement is in
> centimeters or millimeters. This will help you draw with greater
> precision.
>
> You approached learning this term with care and responsibility.
> You took an active part in class and submitted all your
> assignments.

## Recommendations for writing

When you write narrative feedback, keep these guidelines in mind:

**a) Use descriptive language.** Speak to the student's actions
and the quality of their work, not to their personality.
("In English class, you are active." vs. "In English class, you
join in regularly and often help your classmates.")

**b) Avoid manipulative phrases.** "I like…" or "I'm pleased…"
shifts the focus to the teacher's feelings — but the student
should be the one feeling proud. Work with recognition, not praise.

**c) Avoid vague verbs like "you can" or "you know how to."**
Replace them with concrete descriptions of the student's results.
("You can do all numbers up to 20." → "You write all numbers up
to 20 correctly." "You can solve…" → "You solve…")

**d) Don't close the door on growth.** Instead of "You didn't
master…" write "You're still developing…" or "You need more time
with this…"

**e) Have a colleague proofread your text.** A second pair of
eyes catches what you can't see.

## Structure

Content should also be structured. Think through how you'll move
through the narrative. There are several approaches, and the right
one depends on how many subjects you're assessing, the age of your
students, the values that shape your school's reporting, and the
report card template you're using. Each teacher can find their
own path — or the staff can agree on a shared structure.

In general, you can move:

**a) From general to specific** — start with feedback on core
competencies and approach to learning across all subjects, then
move to the level of expected outcomes in each subject.

**b) From specific to general** — describe the level of expected
outcomes in each subject first, and close by summarizing the
student's approach to learning and core competencies.

**c) Through integrated subject-level feedback** — for each
subject, describe both the student's outcomes and their approach
to learning in that subject.

## Form

The form of narrative feedback connects closely to whether the
text becomes part of the official report card or is shared with
students and families through other means.

When writing the text:

**a) Think through how you address the student.** Greetings often
vary by age — for elementary students, "Dear Sophia," in middle
or high school, more often just "Sophia." Some narratives skip
the greeting altogether. This is usually the case when the text
is addressed more to the family than to the student. So the
greeting reflects who the audience is.

**b) Consider the length.** This depends on the student's age and
on how many subjects you're addressing.

**c) Make sure the text is accessible to both the student and the
family.** This is harder than it sounds. Families will understand
simpler text using vocabulary the student knows. The reverse —
text written for adults — is much less useful to the student.

**d) Make sure your evaluations are evidence-based and fair.**

**e) Choose appropriate font and size for the student's age.**
This matters most for students in kindergarten and 1st grade,
particularly if they're still learning to read — their report
card may need to be in print rather than cursive.

**f) End with intention.** Choose a closing that fits the message.

## Building capacity

Every school staff is at a different starting point with narrative
feedback. Where teachers stand depends on the school's values and
instructional approach, on teacher beliefs and pedagogical styles,
on whether ongoing formative assessment is part of practice, on
professional learning, on leadership support, and on a host of
other conditions.

Mandating narrative feedback overnight rarely works and tends to
meet resistance from teachers — and possibly from families who
aren't prepared for the change. On the other hand, waiting
indefinitely doesn't bear fruit either. Writing narrative feedback
takes specific skills that develop over time. Often it helps to
step back from your drafts and reflect on them with some distance —
maybe with the help of a more experienced colleague. The hardest
part is starting and getting past the initial doubts. Progress
follows.