# Core Principles of Narrative Feedback on the Report Card

A report card narrative provides twice-yearly summative information about a student's learning over a defined period. At the same time, it is part of an ongoing system of assessment that is applied systematically and over time. It treats the student holistically: it considers transferable skills, dispositions, and core competencies alongside academic content, and it bridges formative and summative purposes. Its goal is not only to summarize results, but also to identify possibilities for further growth and to support students in taking responsibility for their own learning.

A narrative report card serves two functions:

- A summative function — it provides information about the level of learning and behavior the student has reached during a specific period in relation to learning goals.
- A formative function — it gives the student narrative feedback on their learning process, results, and recommendations for further growth. It also supports student self-reflection and continued development.

The primary purpose of assessment is to support student learning and growth. This is not possible without ongoing supportive feedback, formative assessment, and the student's active participation in the assessment process. Only with these in place can teachers responsibly write a report card that reflects a different conception and quality of assessment. This takes practice, and the principles below can help.

This approach to the report card is grounded in the following general principles, which are applied throughout instruction.

## General principles of assessment

- The defining feature of assessment is its formative purpose. Assessment provides students with ongoing feedback and concrete information about their learning process at a point when they can still improve. This supports student self-reflection, continued growth, and gradual ownership of their own learning.
- Assessment is criterion-based. Student performance is judged against goals, focus areas, and indicators set in advance — not intuitively.
- Assessment is systematic. It draws on planned, ongoing observation and documentation of behaviors and processes that are anchored in success criteria and specified in indicators.
- Assessment is individualized. It does not compare students to one another. A student's performance is judged against their own prior performance, their individuality, and their specific abilities. Assessment reflects the student's current level of mastery, whether they have improved relative to the stated goal, and what their possibilities are for further growth.
- Teacher assessment is supplemented by student self-assessment and peer assessment.
- Assessment is comprehensive. It addresses both the process and the results of learning, in relation to the student's overall development.
- Ongoing assessment culminates in a summative summary of learning outcomes, accompanied by suggestions for the student's continued development.

## Why this approach matters

- Teachers gain a tool that helps them focus on the whole-child development of each student and on a deeper understanding of their strengths — not only in the cognitive domain.
- Teachers are supported in giving ongoing, formative feedback on aspects of learning that are often under-addressed in conventional reporting.
- Students gain a deeper understanding of what is expected of them, the level of mastery being asked for, and how they are progressing during the year. Ongoing formative feedback supports their growth, builds motivation for lifelong learning, and develops ownership of learning. Their results are reported in language they can understand.
- Students, teachers, and families can have meaningful conversations about results and next steps for development.
- Families receive clear information about their child's learning and concrete suggestions for how to support their child at home.
