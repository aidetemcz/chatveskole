# Narrative Feedback in Arts and Specials

This file applies to narrative feedback in arts and specials: visual art, music, physical education, and related subjects (sometimes called "related arts" or "encore" subjects).

The purpose of these subjects is largely developmental — helping students discover something that may stay with them throughout life and bring them joy. The aim is for students to explore the worlds of music, visual art, movement, and hands-on creative work; to develop their skills with intention and the courage to try new and unfamiliar things.

Arts and specials are an essential part of whole-child education. They can help students discover their talents and find activities that engage them outside of school. What matters most is to consistently strengthen each student's distinctive strengths in these subjects so they experience success, feel motivated to experiment, and develop the confidence to push beyond familiar patterns.

When real-world themes are connected with creative work, students' attitudes and ethical commitments can develop in significant ways. For this reason, arts and specials have an irreplaceable role in education and deserve real space in the school day.

The purpose of narrative feedback in these subjects is to support the student in their growth. For this reason, these subjects are typically reported through narrative feedback rather than through letter or proficiency grades — the report card offers the teacher space for written commentary.

## Writing the narrative

Because the goal of feedback in arts and specials is to support the student's growth as a self-aware, autonomous, responsible person — and to support the expression of positive feelings through actions, choices, and lived experience — these subjects are not graded with letters or scales. The report card includes narrative feedback only.

The narrative does not need to be long. The teacher addresses the learning that was the focus of the term, in alignment with the school's curriculum. The teacher highlights the student's strengths and notes specific successes. The teacher recommends strategies that would support continued growth. Student self-assessment can also be drawn on. If the teacher does not see specific areas for growth, they may simply suggest the student continue working in the same way during the next term.

## Examples of narrative feedback that recognize strengths and growth

- You've made significant progress in track and field events thanks to your persistence and your willingness to push through challenges.
- You participate fully in all movement activities and try new ones with energy and enthusiasm.
- You put real effort into reaching the goals you set for yourself.
- You track and reflect on your own performance and work consistently to improve your fitness.
- You know your way around the world of sports and stay involved in physical activity outside of school.
- You apply the movement skills you've developed creatively in games and competitive play.

## Common pitfalls to watch for

- Some teachers in arts and specials see students only once a week, sometimes less often. This makes it harder to gather evidence of how each student is developing. This is exactly why these "less visible" students need focused attention. Teachers will need tools and approaches for observing students and recording information about each one over time.
- Risk of formulaic narratives. When teachers face heavy caseloads, it's easy to slip into copy-and-paste comments. Even when several students are at similar levels and recommendations overlap, narrative feedback still says more than a single letter grade does. Schools can offer teachers a starting list of categories worth reporting on in each subject — and that list can keep growing.
- Risk of overly long, hard-to-follow narratives. The aim is to focus on one or two areas that were the main focus of the term, or where the student has clearly grown.

## What strong narrative feedback offers in arts and specials

- Narrative feedback supports teachers in paying closer attention to the learning process and to student outcomes. Teachers can have richer conversations with their students about growth and about how each student approaches the work.
- Over time, the field of what is worth reporting on — what matters in arts and specials — keeps expanding for everyone.
- Narrative feedback invites teachers to bring students more actively into the self-assessment process.
- Teachers develop tools for documenting student learning over time — observation notes, conversations with students, portfolios, and other evidence-gathering practices.
